"""Interactive Pygame-CE front end.  The SAME Simulation engine as headless experiments
is stepped here at fixed dt; rendering only reads its state.

  python -m src.visualizer --scenario braess
  python -m src.visualizer --scenario mission --fleet 4 --seed 42 --policy control-aware
  python -m src.visualizer --scenario compare --seed 42 --policy P2 --policy-b P3
  python -m src.visualizer --scenario scale --fleet 12
Headless screenshots:
  python -m src.visualizer --scenario mission --sim-time 60 --screenshot figures/shot.png
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time

import pygame

from .config import SimConfig
from .policies import POLICY_INFO
from .sim import Simulation
from .viz import theme as T
from .viz.braess_view import BraessScene
from .viz.mission_view import MissionView, draw_panel, glass, text

ALIASES = {"control-aware": "P3", "graph": "P2", "selfish": "P1", "greedy": "P0",
           "central": "P4", "centralized": "P4"}
POLICIES = ["P0", "P1", "P2", "A1", "A2", "P3", "P4"]
COMMS = ["ideal", "degraded", "none"]
SPEEDS = [("x0.25", 0.25), ("x1", 1.0), ("x4", 4.0), ("x16", 16.0)]
MODES = ["braess", "mission", "scale", "compare"]
MODE_TITLE = {"braess": "A  EXACT GAME", "mission": "B  MISSION", "scale": "C  FLEET STRESS",
              "compare": "D  SPLIT COMPARISON"}
TOP_H, BOT_H, PANEL_W = 46, 54, 420


class App:
    def __init__(self, args):
        self.args = args
        pygame.init()
        flags = 0 if args.screenshot else pygame.RESIZABLE
        self.screen = pygame.display.set_mode((args.width, args.height), flags)
        pygame.display.set_caption("The Wrong Gradient | multi-RoboBoat coordination lab")
        self.clock = pygame.time.Clock()
        self.mode = args.scenario
        self.seed = args.seed
        self.fleet = args.fleet
        self.policy = ALIASES.get(args.policy, args.policy)
        self.policy_b = ALIASES.get(args.policy_b, args.policy_b)
        self.comm = args.comm
        self.speed_idx = 1
        self.paused = False
        self.help = False
        self.toast = None
        self.braess = BraessScene()
        self.views = []
        self.replay = []
        self.build()

    # -------------------------------------------------------------------------------
    def layout(self):
        w, h = self.screen.get_size()
        if self.mode == "compare":
            return pygame.Rect(0, TOP_H, w, h - TOP_H - BOT_H), None
        view = pygame.Rect(0, TOP_H, w - PANEL_W, h - TOP_H - BOT_H)
        panel = pygame.Rect(w - PANEL_W + 8, TOP_H + 8, PANEL_W - 16, h - TOP_H - BOT_H - 16)
        return view, panel

    def make_sim(self, policy, fleet=None):
        cfg = SimConfig(n_boats=fleet or self.fleet, policy=policy, comm_mode=self.comm)
        if self.args.episode:
            cfg = cfg.replace(episode_s=self.args.episode)
        return Simulation(cfg, self.seed)

    def build(self):
        view, panel = self.layout()
        self.views = []
        self.replay = []
        if self.mode == "mission":
            self.views = [MissionView(self.make_sim(self.policy), view)]
        elif self.mode == "scale":
            self.views = [MissionView(self.make_sim(self.policy), view)]
        elif self.mode == "compare":
            l = pygame.Rect(view.x, view.y, view.w // 2 - 2, view.h)
            r = pygame.Rect(view.x + view.w // 2 + 2, view.y, view.w // 2 - 2, view.h)
            a, b = self.make_sim(self.policy), self.make_sim(self.policy_b)
            self.views = [MissionView(a, l, f"{self.policy}"), MissionView(b, r, f"{self.policy_b}", label_right=True)]

    def say(self, s, color=T.ACCENT):
        self.toast = (s, color, time.time())

    # -------------------------------------------------------------------------------
    def handle(self, ev):
        if ev.type == pygame.QUIT:
            return False
        if ev.type == pygame.VIDEORESIZE:
            self.screen = pygame.display.set_mode((max(1100, ev.w), max(700, ev.h)), pygame.RESIZABLE)
            self.build(); return True
        if ev.type == pygame.KEYDOWN:
            k = ev.key
            if k == pygame.K_ESCAPE:
                return False
            if k == pygame.K_TAB:
                self.mode = MODES[(MODES.index(self.mode) + 1) % len(MODES)]
                if self.mode == "scale" and self.fleet < 8:
                    self.fleet = 8
                if self.mode == "mission":
                    self.fleet = self.args.fleet
                self.build(); self.say(MODE_TITLE[self.mode]); return True
            if k == pygame.K_h:
                self.help = not self.help; return True
            if k == pygame.K_F2 or (k == pygame.K_s and ev.mod & pygame.KMOD_CTRL):
                self.snapshot(); return True
            if self.mode == "braess":
                self.braess.handle_key(k); return True
            if k == pygame.K_SPACE:
                self.paused = not self.paused
            elif k in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4):
                self.speed_idx = {pygame.K_1: 1, pygame.K_2: 2, pygame.K_3: 3, pygame.K_4: 0}[k]
                self.say(f"speed {SPEEDS[self.speed_idx][0]}")
            elif k == pygame.K_n:
                for v in self.views:
                    for _ in range(int(0.1 / v.sim.cfg.dt)):
                        v.sim.step()
                self.paused = True
            elif k == pygame.K_r:
                self.seed += 1; self.build(); self.say(f"reseeded: world {self.seed}")
            elif k == pygame.K_p:
                self.policy = POLICIES[(POLICIES.index(self.policy) + 1) % len(POLICIES)]
                self.build(); self.say(f"policy {self.policy}: {POLICY_INFO[self.policy]}")
            elif k == pygame.K_b and self.mode == "compare":
                self.policy_b = POLICIES[(POLICIES.index(self.policy_b) + 1) % len(POLICIES)]
                self.build(); self.say(f"right policy {self.policy_b}")
            elif k == pygame.K_c:
                self.comm = COMMS[(COMMS.index(self.comm) + 1) % len(COMMS)]
                self.build(); self.say(f"comms: {self.comm}")
            elif k == pygame.K_v:
                for v in self.views:
                    v.show_sensors = not v.show_sensors
            elif k == pygame.K_g:
                for v in self.views:
                    v.show_graph = not v.show_graph
            elif k == pygame.K_f:
                for v in self.views:
                    v.show_flow = not v.show_flow
            elif k in (pygame.K_EQUALS, pygame.K_PLUS, pygame.K_KP_PLUS):
                self.fleet = min(16, self.fleet + 1); self.build(); self.say(f"fleet {self.fleet}")
            elif k in (pygame.K_MINUS, pygame.K_KP_MINUS):
                self.fleet = max(2, self.fleet - 1); self.build(); self.say(f"fleet {self.fleet}")
            elif k == pygame.K_e:
                self.export_replay()
            elif k == pygame.K_o:
                self.open_failure_case()
        if ev.type == pygame.MOUSEWHEEL and self.views:
            for v in self.views:
                if v.cam.rect.collidepoint(pygame.mouse.get_pos()):
                    mx, my = pygame.mouse.get_pos()
                    wx, wy = v.cam.to_world(mx, my)
                    v.cam.zoom = max(1.0, min(4.0, v.cam.zoom * (1.15 if ev.y > 0 else 1 / 1.15)))
                    nx, ny = v.cam.to_world(mx, my)
                    v.cam.cx += wx - nx; v.cam.cy += wy - ny
        if ev.type == pygame.MOUSEMOTION and ev.buttons[0] and self.views:
            for v in self.views:
                if v.cam.rect.collidepoint(ev.pos):
                    v.cam.cx -= ev.rel[0] / v.cam.scale; v.cam.cy += ev.rel[1] / v.cam.scale
        return True

    def snapshot(self, path=None):
        os.makedirs("figures/screenshots", exist_ok=True)
        path = path or f"figures/screenshots/{self.mode}_{int(time.time())}.png"
        pygame.image.save(self.screen, path)
        self.say(f"saved {path}")
        return path

    def export_replay(self):
        if not self.views:
            return
        os.makedirs("replays", exist_ok=True)
        out = []
        for v in self.views:
            sim = v.sim
            out.append(dict(seed=sim.seed, config=sim.cfg.to_dict(), config_hash=sim.cfg.hash(),
                            t=sim.t, samples=self.replay,
                            events=[e.__dict__ for e in sim.events if e.kind != "decide"],
                            note="Deterministic: re-running Simulation(config, seed) reproduces this "
                                 "episode exactly; samples are for quick inspection."))
        path = f"replays/replay_{self.mode}_seed{self.seed}_{self.policy}_{int(time.time())}.json"
        with open(path, "w") as f:
            json.dump(out, f, default=float)
        self.say(f"replay saved {path}")

    def open_failure_case(self):
        p = "data/failure_cases.json"
        if not os.path.exists(p):
            self.say("no failure-case file yet (run analysis)", T.WARN); return
        cases = json.load(open(p))
        if not cases:
            return
        self._fc = (getattr(self, "_fc", -1) + 1) % len(cases)
        c = cases[self._fc]
        self.seed, self.comm = int(c["seed"]), c["comm_mode"]
        self.policy, self.policy_b = c["policy_a"], c["policy_b"]
        self.fleet = int(c.get("n_boats", 4))
        self.mode = "compare"; self.build()
        self.say(f"failure case {self._fc + 1}/{len(cases)}: {c.get('note', '')}", T.WARN)

    # -------------------------------------------------------------------------------
    def step_sims(self, real_dt):
        if self.mode == "braess" or self.paused or not self.views:
            return 0.0
        sp = SPEEDS[self.speed_idx][1]
        sim0 = self.views[0].sim
        target = sim0.t + sp * real_dt
        before = sim0.t
        while sim0.t + 1e-9 < target and not sim0.done:
            for v in self.views:
                v.sim.step()
        if int(sim0.t * 2) != int(before * 2):
            self.replay.append([round(sim0.t, 2)] + [[round(float(a), 2) for a in v.sim.S[:3].ravel()] for v in self.views])
        return sim0.t - before

    def draw_top(self):
        w = self.screen.get_width()
        bar = pygame.Rect(0, 0, w, TOP_H)
        pygame.draw.rect(self.screen, (8, 16, 26), bar)
        pygame.draw.line(self.screen, T.PANEL_EDGE, (0, TOP_H - 1), (w, TOP_H - 1))
        text(self.screen, "THE WRONG GRADIENT", (16, 13), 17, T.TEXT, True)
        x = 240
        for m in MODES:
            act = m == self.mode
            r = pygame.Rect(x, 9, 168, 28)
            pygame.draw.rect(self.screen, (20, 44, 60) if act else (12, 24, 36), r, border_radius=8)
            pygame.draw.rect(self.screen, T.ACCENT if act else T.PANEL_EDGE, r, 1, border_radius=8)
            text(self.screen, MODE_TITLE[m], r.center, 12, T.ACCENT if act else T.MUTED, True, "c")
            x += 176
        if self.mode != "braess":
            st = "PAUSED" if self.paused else SPEEDS[self.speed_idx][0]
            text(self.screen, f"world #{self.seed}   fleet {self.fleet}   {st}", (w - 16, 15), 13,
                 T.WARN if self.paused else T.TEXT, True, "tr")
        text(self.screen, f"{self.clock.get_fps():4.0f} fps", (w - 16, TOP_H - 2), 9, T.MUTED, False, "tr") \
            if False else None

    def draw_timeline(self):
        w, h = self.screen.get_size()
        r = pygame.Rect(12, h - BOT_H + 6, (w if self.mode == "compare" else w - PANEL_W) - 24, BOT_H - 14)
        glass(self.screen, r, 200, 8)
        if self.mode == "braess" or not self.views:
            text(self.screen, "Exact finite game: every number on screen is computed with exact rational "
                 "arithmetic (src/game_exact.py) and verified by exhaustive enumeration in tests.",
                 (r.x + 12, r.centery), 12, T.MUTED, False, "ml")
            return
        sim = self.views[0].sim
        E = sim.cfg.episode_s
        X = lambda t: r.x + 10 + (r.w - 20) * t / E
        n = len(sim.tasks)
        for k, tk in enumerate(sim.tasks):
            y = r.y + 6 + (r.h - 12) * k / max(1, n)
            hh = max(2, (r.h - 12) / max(1, n) - 1)
            col = T.TASK_COLORS[tk.kind]
            pygame.draw.rect(self.screen, tuple(c // 3 for c in col), (X(tk.release), y, X(min(E, tk.deadline)) - X(tk.release), hh))
            if tk.completed_at is not None:
                pygame.draw.rect(self.screen, col, (X(tk.release), y, X(tk.completed_at) - X(tk.release), hh))
                pygame.draw.circle(self.screen, T.BOAT_COLORS[tk.completed_by % 16], (X(tk.completed_at), y + hh / 2), 3)
        cx = X(sim.t)
        pygame.draw.line(self.screen, T.TEXT, (cx, r.y + 2), (cx, r.bottom - 2), 2)
        text(self.screen, "tasks: release -> deadline (filled = completed)", (r.right - 10, r.y + 2), 9, T.MUTED, False, "tr")

    def draw_help(self):
        w, h = self.screen.get_size()
        r = pygame.Rect(0, 0, 640, 470); r.center = (w // 2, h // 2)
        glass(self.screen, r, 245, 16, T.ACCENT)
        lines = [("CONTROLS", T.ACCENT, True),
                 ("TAB  switch mode (A exact game, B mission, C stress, D split)", T.TEXT, False),
                 ("SPACE pause/resume    N step 0.1 s    1/2/3 speed x1/x4/x16    4 slow-mo x0.25", T.TEXT, False),
                 ("P cycle policy    B right-hand policy (split)    C comms ideal/degraded/none", T.TEXT, False),
                 ("R reseed world    +/- fleet size (2-16)    O open next failure case", T.TEXT, False),
                 ("V sensor rings    G ETA labels (graph | control | elapsed)    F current tracers", T.TEXT, False),
                 ("mouse wheel zoom    drag pan    F2 screenshot    E export replay", T.TEXT, False),
                 ("", T.TEXT, False),
                 ("EXACT GAME (mode A)", T.ACCENT, True),
                 ("SPACE best-response move    A autoplay    M marginal-cost tolls", T.TEXT, False),
                 ("O open/close shortcut    R reset    4 Monderer-Shapley 4-cycle test", T.TEXT, False),
                 ("", T.TEXT, False),
                 ("WHAT YOU SEE", T.ACCENT, True),
                 ("dashed lines = planned routes; dots on links = packets in flight;", T.MUTED, False),
                 ("red X = dropped packet; ring around a task = time to deadline;", T.MUTED, False),
                 ("1-LANE channels hold one boat (green free / red occupied).", T.MUTED, False),
                 ("Boats drawn ~2-3x larger than scale for visibility (physics uses true size).", T.MUTED, False)]
        y = r.y + 20
        for s, c, b in lines:
            text(self.screen, s, (r.x + 24, y), 13, c, b); y += 24

    def draw_compare_overlay(self, view):
        ms = [v.live_metrics() for v in self.views]
        for v, m in zip(self.views, ms):
            r = pygame.Rect(0, 0, 430, 104)
            r.bottomleft = (v.cam.rect.x + 14, v.cam.rect.bottom - 14)
            glass(self.screen, r, 225, 10)
            p = v.sim.cfg.policy
            text(self.screen, POLICY_INFO[p], (r.x + 12, r.y + 8), 11, T.MUTED)
            text(self.screen, "W", (r.x + 12, r.y + 30), 12, T.MUTED, True)
            text(self.screen, f"{m['welfare']:+.1f}", (r.x + 30, r.y + 24), 26, T.GOOD if m['welfare'] >= 0 else T.BAD, True)
            text(self.screen, f"pts {m['points']}", (r.x + 150, r.y + 30), 13, T.TEXT, True)
            text(self.screen, f"done {m['completed']}   expired {m['expired']}   redundant {m['redundant']}   contacts {m['collisions']}",
                 (r.x + 12, r.y + 66), 11, T.TEXT)
            text(self.screen, f"target switches {sum(mm.switches for mm in v.sim.minds)}", (r.x + 12, r.y + 84), 11, T.MUTED)
        d = ms[1]["welfare"] - ms[0]["welfare"]
        r = pygame.Rect(0, 0, 250, 96); r.midtop = (view.centerx, view.y + 12)
        glass(self.screen, r, 235, 12, T.ACCENT)
        text(self.screen, "PAIRED DIFFERENCE  W(right) - W(left)", (r.centerx, r.y + 12), 10, T.MUTED, True, "c")
        text(self.screen, f"{d:+.1f}", (r.centerx, r.y + 44), 32, T.GOOD if d >= 0 else T.BAD, True, "c")
        text(self.screen, "same world, currents, tasks & packet-loss tapes", (r.centerx, r.y + 78), 9, T.MUTED, False, "c")

    def draw(self, real_dt, sim_dt):
        self.screen.fill(T.BG)
        view, panel = self.layout()
        if self.mode == "braess":
            self.braess.update(real_dt)
            self.braess.draw(self.screen, view, panel)
        else:
            for v in self.views:
                v.update(real_dt, sim_dt)
                v.draw(self.screen)
            if self.mode == "compare":
                pygame.draw.line(self.screen, T.ACCENT, (view.centerx, view.y), (view.centerx, view.bottom), 2)
                self.draw_compare_overlay(view)
            else:
                extra = ["SPACE pause  1/2/3 speed  P policy  C comms  R reseed", "G ETA labels  V sensors  TAB mode  H help"]
                draw_panel(self.screen, panel, self.views[0], extra)
            sim = self.views[0].sim
            if sim.done:
                text(self.screen, "EPISODE COMPLETE  (R = new world)", (view.centerx, view.y + 30), 22, T.ACCENT, True, "c")
        self.draw_top()
        self.draw_timeline()
        if self.toast and time.time() - self.toast[2] < 2.5:
            s, c, _ = self.toast
            img = T.font(15, True).render(s, True, c)
            r = pygame.Rect(0, 0, img.get_width() + 30, 34); r.midbottom = (view.centerx, view.bottom - 14)
            glass(self.screen, r, 230, 10, c)
            self.screen.blit(img, (r.x + 15, r.y + 8))
        if self.help:
            self.draw_help()

    def run(self):
        a = self.args
        if a.screenshot:
            return self.run_scripted()
        running = True
        while running:
            real_dt = min(0.05, self.clock.tick(60) / 1000.0)
            for ev in pygame.event.get():
                running = self.handle(ev) and running
            sim_dt = self.step_sims(real_dt)
            self.draw(real_dt, sim_dt)
            pygame.display.flip()
        pygame.quit()

    def run_scripted(self):
        """Headless: fast-forward to --sim-time, then render frames so particles/trails
        develop, then save. Braess: apply --braess-moves best-response steps."""
        a = self.args
        if self.mode == "braess":
            if a.marginal:
                self.braess.handle_key(pygame.K_m)
            if a.cycle:
                self.braess.show_cycle = True
            for _ in range(a.braess_moves):
                self.braess.step()
            if self.braess.banner:
                self.braess.banner = (*self.braess.banner[:3], 0.0)
            self.braess.t = 0.6
            self.braess.update(0.0)
            for _ in range(a.frames):
                self.draw(1 / 60, 0)
        else:
            sim0 = self.views[0].sim
            lead = max(0.0, a.sim_time - 6.0)
            while sim0.t < lead:
                for v in self.views:
                    v.sim.step()
            for v in self.views:                 # don't replay old events as fresh FX
                v.ev_idx = len(v.sim.events)
                v.cam.zoom = a.zoom
            for _ in range(a.frames):
                d = self.step_sims(1 / 60.0) if sim0.t < a.sim_time else 0.0
                if sim0.t < a.sim_time:
                    # advance faster during the lead-in so wakes/tracers develop
                    for _k in range(int(4 * (1 / 60) / sim0.cfg.dt)):
                        for v in self.views:
                            v.sim.step()
                    d += 4 / 60
                if a.focus_boat >= 0:
                    for v in self.views:
                        v.cam.cx, v.cam.cy = float(v.sim.S[0, a.focus_boat]), float(v.sim.S[1, a.focus_boat])
                self.draw(1 / 60, d)
            if a.help_overlay:
                self.help = True; self.draw(0, 0)
        os.makedirs(os.path.dirname(a.screenshot) or ".", exist_ok=True)
        pygame.image.save(self.screen, a.screenshot)
        print("saved", a.screenshot)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--scenario", choices=MODES, default="mission")
    ap.add_argument("--fleet", type=int, default=4)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--policy", default="P3")
    ap.add_argument("--policy-b", default="P2")
    ap.add_argument("--comm", choices=COMMS, default="degraded")
    ap.add_argument("--episode", type=float, default=None)
    ap.add_argument("--width", type=int, default=1600)
    ap.add_argument("--height", type=int, default=960)
    ap.add_argument("--screenshot", default=None)
    ap.add_argument("--sim-time", type=float, default=40.0)
    ap.add_argument("--frames", type=int, default=90)
    ap.add_argument("--braess-moves", type=int, default=1)
    ap.add_argument("--marginal", action="store_true")
    ap.add_argument("--cycle", action="store_true")
    ap.add_argument("--help-overlay", action="store_true")
    ap.add_argument("--zoom", type=float, default=1.0)
    ap.add_argument("--focus-boat", type=int, default=-1)
    args = ap.parse_args(argv)
    args.policy = ALIASES.get(args.policy, args.policy)
    args.policy_b = ALIASES.get(args.policy_b, args.policy_b)
    if args.screenshot:
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    App(args).run()


if __name__ == "__main__":
    main()
