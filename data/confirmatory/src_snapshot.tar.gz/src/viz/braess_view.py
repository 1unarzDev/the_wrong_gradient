"""Mode A: the exact Braess / potential-game scene.  Every number shown is computed
live by src.game_exact with exact fractions."""
from __future__ import annotations

import math
from fractions import Fraction

import numpy as np
import pygame

from ..game_exact import (analyze, braess_game, four_cycle_sums, matching_pennies_cost)
from . import fx
from . import theme as T
from .mission_view import glass, text

NODE_POS = {"S": (0.10, 0.50), "A": (0.50, 0.16), "B": (0.50, 0.84), "T": (0.90, 0.50)}
NODE_NAME = {"S": "DOCK  S", "A": "BUOY A", "B": "BUOY B", "T": "INSPECTION  T"}
EDGE_STYLE = {("S", "A"): "canal", ("B", "T"): "canal", ("A", "T"): "lake", ("S", "B"): "lake",
              ("A", "B"): "gate"}


def thick(L, color, pts, width):
    """Smooth thick stroke: overlapping discs along a densely resampled polyline."""
    pts = np.asarray(pts, float)
    seg = np.linalg.norm(np.diff(pts, axis=0), axis=1)
    s = np.concatenate([[0], np.cumsum(seg)])
    n = max(2, int(s[-1] / max(1.0, width / 4)))
    u = np.linspace(0, s[-1], n)
    xs, ys = np.interp(u, s, pts[:, 0]), np.interp(u, s, pts[:, 1])
    r = max(1, width // 2)
    for x, y in zip(xs, ys):
        pygame.draw.circle(L, color, (x, y), r)


def fr(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


class BraessScene:
    def __init__(self):
        self.shortcut = True
        self.marginal = False
        self.autoplay = False
        self.show_cycle = False
        self.caustics = fx.caustics_texture(seed=11, intensity=0.45)
        self.parts = fx.Particles()
        self.t = 0.0
        self.auto_timer = 0.0
        self.banner = None          # (text1, text2, color, t0)
        self.reset()

    # -------------------------------------------------------------------------------
    def reset(self):
        self.game = braess_game(self.shortcut, 4)
        g = self.game
        sat = g.routes.index((("S", "A"), ("A", "T")))
        sbt = g.routes.index((("S", "B"), ("B", "T")))
        self.profile = [sat, sat, sbt, sbt]
        self.ptr = 0
        self.history = [(self.phi(), g.team_cost(self.profile))]
        self.last = None
        self.at_ne = False
        self.analysis = analyze(g, g.marginal_cost if self.marginal else None)
        self.opt = analyze(g).optimum_cost
        self.progress = [k * 0.23 for k in range(4)]
        self.banner = None

    def ecost(self):
        return self.game.marginal_cost if self.marginal else None

    def phi(self):
        return self.game.potential(self.profile, self.ecost())

    def step(self):
        g = self.game
        for k in range(4):
            i = (self.ptr + k) % 4
            old = g.private_cost(self.profile, i, self.ecost())
            r, new = g.best_response(self.profile, i, self.ecost())
            if new < old:
                C0 = g.team_cost(self.profile); P0 = self.phi()
                true_old = g.private_cost(self.profile, i)
                old_r = self.profile[i]
                self.profile[i] = r
                C1 = g.team_cost(self.profile); P1 = self.phi()
                true_new = g.private_cost(self.profile, i)
                self.history.append((P1, C1))
                self.last = dict(i=i, old=old_r, new=r, c_old=old, c_new=new, C0=C0, C1=C1,
                                 P0=P0, P1=P1, true_old=true_old, true_new=true_new)
                self.ptr = (i + 1) % 4
                self.progress[i] = 0.0
                if C1 > C0:
                    self.banner = (f"Boat {i + 1} saved {fr(old - new)} min for itself",
                                   f"...and the fleet lost {fr(C1 - C0)} min", T.BAD, self.t)
                else:
                    self.banner = (f"Boat {i + 1} improved by {fr(old - new)}",
                                   f"fleet cost fell by {fr(C0 - C1)} min", T.GOOD, self.t)
                return True
        self.at_ne = True
        self.banner = ("Nash equilibrium", "no boat can improve by deviating alone", T.ACCENT, self.t)
        return False

    def handle_key(self, key):
        if key == pygame.K_SPACE:
            self.step()
        elif key == pygame.K_a:
            self.autoplay = not self.autoplay
        elif key == pygame.K_m:
            self.marginal = not self.marginal
            prof = list(self.profile)
            self.analysis = analyze(self.game, self.game.marginal_cost if self.marginal else None)
            self.history = [(self.phi(), self.game.team_cost(prof))]
            self.at_ne = False; self.last = None
            self.banner = (("MARGINAL-COST INCENTIVES ON" if self.marginal else "SELFISH COSTS"),
                           ("each boat pays m_e(k) = k c(k) - (k-1) c(k-1)" if self.marginal
                            else "each boat pays its own travel time"), T.WARN, self.t)
        elif key == pygame.K_o:
            self.shortcut = not self.shortcut
            self.reset()
        elif key == pygame.K_r:
            self.reset()
        elif key == pygame.K_4:
            self.show_cycle = not self.show_cycle

    # -------------------------------------------------------------------------------
    def update(self, dt):
        self.t += dt
        if self.autoplay and not self.at_ne:
            self.auto_timer += dt
            if self.auto_timer > 2.2:
                self.auto_timer = 0
                self.step()
        g = self.game
        loads = g.loads(self.profile)
        for i in range(4):
            route = g.routes[self.profile[i]]
            total = float(sum(g.c(e, loads[e]) for e in route))
            self.progress[i] = (self.progress[i] + dt / (0.22 * total)) % 1.0
        self.parts.update(dt)

    # -------------------------------------------------------------------------------
    def _pos(self, rect, n):
        fx_, fy = NODE_POS[n]
        return (rect.x + rect.w * fx_, rect.y + rect.h * fy)

    def _edge_pts(self, rect, e, k=40):
        a, b = np.array(self._pos(rect, e[0])), np.array(self._pos(rect, e[1]))
        st = EDGE_STYLE[e]
        mid = (a + b) / 2
        d = b - a
        nrm = np.array([-d[1], d[0]]) / (np.linalg.norm(d) + 1e-9)
        bend = {"canal": 0.16, "lake": 0.30, "gate": 0.0}[st]
        c0 = np.array([rect.x + rect.w * 0.5, rect.y + rect.h * 0.5])
        if np.dot(nrm, mid - c0) < 0:          # always bow AWAY from the central island
            nrm = -nrm
        if st == "lake":                        # lakes run outside the canals
            pass
        ctrl = mid + nrm * bend * np.linalg.norm(d)
        ts = np.linspace(0, 1, k)[:, None]
        return (1 - ts) ** 2 * a + 2 * (1 - ts) * ts * ctrl + ts ** 2 * b

    def draw(self, screen, rect, panel):
        g = self.game
        screen.set_clip(rect)
        # ocean gradient + caustics
        grad = pygame.Surface((1, 2)); grad.set_at((0, 0), T.MID); grad.set_at((0, 1), T.DEEP)
        screen.blit(pygame.transform.smoothscale(grad, rect.size), rect.topleft)
        cs = self.caustics; tw = cs.get_width()
        offx = int(self.t * 8) % tw; offy = int(self.t * 4) % tw
        for X in range(rect.left - offx, rect.right, tw):
            for Y in range(rect.top - offy, rect.bottom, tw):
                screen.blit(cs, (X, Y), special_flags=pygame.BLEND_ADD)
        L = pygame.Surface(rect.size, pygame.SRCALPHA)
        off = np.array(rect.topleft)
        # central island split by the shortcut canal
        cx, cy = rect.x + rect.w * 0.5, rect.y + rect.h * 0.5
        for side in (-1, 1):
            pts = []
            for a in np.linspace(0, 2 * np.pi, 40):
                rx = rect.w * 0.12 * (1 + 0.08 * math.sin(3 * a + side))
                ry = rect.h * 0.17 * (1 + 0.06 * math.cos(4 * a))
                px = cx + side * rect.w * 0.085 + rx * math.cos(a) * 0.62
                py = cy + ry * math.sin(a)
                pts.append((px - rect.x, py - rect.y))
            pygame.draw.polygon(L, (*T.FOAM, 50), [(x + 6 * math.cos(math.atan2(y - cy + rect.y, x - cx + rect.x)), y) for x, y in pts])
            pygame.draw.polygon(L, (*T.SAND, 255), pts)
            inner = [(cx - rect.x + side * rect.w * 0.085 + (x - (cx - rect.x + side * rect.w * 0.085)) * 0.8,
                      (cy - rect.y) + (y - (cy - rect.y)) * 0.8) for x, y in pts]
            pygame.draw.polygon(L, (*T.GRASS, 255), inner)
        loads = g.loads(self.profile)
        ec = self.ecost() or g.c
        for e in g.edges:
            pts = self._edge_pts(rect, e.key) - off
            st = EDGE_STYLE[e.key]
            k = loads[e.key]
            if st == "canal":
                heat = T.lerp(T.GOOD, T.BAD, (k - 1) / 3) if k else (80, 120, 140)
                w = 26
                thick(L, (*T.SHALLOW, 255), pts, w + 10)
                thick(L, (*heat, 255), pts, w)
            elif st == "lake":
                thick(L, (60, 130, 160, 255), pts, 44)
                thick(L, (150, 215, 240, 255), pts, 3)
            else:
                pygame.draw.lines(L, (*T.SHALLOW, 255), False, pts.tolist(), 26)
                pygame.draw.lines(L, (*T.ACCENT, 200), False, pts.tolist(), 6)
            # flowing chevrons along the edge
            n = len(pts)
            for q in range(6):
                f = (q / 6 + self.t * 0.12) % 1.0
                idx = int(f * (n - 2))
                p, p2 = pts[idx], pts[idx + 1]
                d = (p2 - p) / (np.linalg.norm(p2 - p) + 1e-9)
                nn = np.array([-d[1], d[0]])
                tip = p + d * 7
                pygame.draw.lines(L, (255, 255, 255, 110), False,
                                  [(p - d * 3 + nn * 6).tolist(), tip.tolist(), (p - d * 3 - nn * 6).tolist()], 2)
            # label
            mid = pts[len(pts) // 2]
            nrm = np.array([0, -1]) if e.key[0] != "A" else np.array([1, 0])
            lab_pos = mid + (np.array([0, -38]) if e.key in (("S", "A"), ("A", "T")) else
                             np.array([0, 38]) if e.key in (("S", "B"), ("B", "T")) else np.array([70, 0]))
            cost_now = ec(e.key, k) if k else ec(e.key, 1)
            if self.marginal:
                formula = {"2k": "m(k)=4k-2", "10": "m(k)=10", "1": "m(k)=1"}[e.label]
            else:
                formula = f"c(k)={e.label}"
            box = pygame.Rect(0, 0, 150, 40); box.center = lab_pos.tolist()
            pygame.draw.rect(L, (8, 18, 28, 210), box, border_radius=8)
            pygame.draw.rect(L, (*T.PANEL_EDGE, 220), box, 1, border_radius=8)
            img = T.font(13, True).render(formula, True, T.ACCENT if not self.marginal else T.WARN)
            L.blit(img, (box.centerx - img.get_width() / 2, box.y + 3))
            img = T.font(12).render(f"k={k} boats -> {fr(cost_now)} min", True, T.TEXT)
            L.blit(img, (box.centerx - img.get_width() / 2, box.y + 21))
        # nodes
        for nname in NODE_POS:
            p = np.array(self._pos(rect, nname)) - off
            pygame.draw.circle(L, (0, 0, 0, 110), (p + 4).tolist(), 30)
            pygame.draw.circle(L, (12, 24, 36, 255), p.tolist(), 28)
            pygame.draw.circle(L, (*T.ACCENT, 255), p.tolist(), 28, 3)
            img = T.font(22, True).render(nname, True, T.TEXT)
            L.blit(img, (p[0] - img.get_width() / 2, p[1] - img.get_height() / 2))
            img = T.font(12, True).render(NODE_NAME[nname], True, T.TEXT)
            dy = {"A": -52, "B": 36, "S": 36, "T": 36}[nname]
            bg = pygame.Rect(0, 0, img.get_width() + 12, img.get_height() + 4)
            bg.midtop = (p[0], p[1] + dy)
            pygame.draw.rect(L, (8, 18, 28, 220), bg, border_radius=6)
            L.blit(img, (bg.x + 6, bg.y + 2))
        if not self.shortcut:
            p = np.array(self._pos(rect, "A")) * 0.5 + np.array(self._pos(rect, "B")) * 0.5 - off
            img = T.font(14, True).render("SHORTCUT CLOSED  (press O)", True, T.BAD)
            L.blit(img, (p[0] - img.get_width() / 2, p[1] - 8))
        screen.blit(L, rect.topleft)
        # boats moving along their routes
        for i in range(4):
            route = g.routes[self.profile[i]]
            costs = [float(g.c(e, loads[e])) for e in route]
            tot = sum(costs)
            s = self.progress[i] * tot
            for e, ce in zip(route, costs):
                if s <= ce:
                    f = s / ce
                    break
                s -= ce
            pts = self._edge_pts(rect, e)
            idx = min(len(pts) - 2, int(f * (len(pts) - 1)))
            p = pts[idx]; d = pts[idx + 1] - pts[idx]
            nrm = np.array([-d[1], d[0]]) / (np.linalg.norm(d) + 1e-9)
            p = p + nrm * (i - 1.5) * 7
            psi = math.atan2(-d[1], d[0])
            col = T.BOAT_COLORS[i]
            fx.blit_glow(screen, tuple(int(c * 0.6) for c in col), p, 30, 0.7)
            fx.draw_boat(screen, p, psi, col, 40)
            tag = T.font(11, True).render(f"B{i + 1}", True, (10, 14, 20))
            tr = pygame.Rect(0, 0, tag.get_width() + 8, 15); tr.center = (p[0], p[1] - 24)
            pygame.draw.rect(screen, col, tr, border_radius=6)
            screen.blit(tag, (tr.x + 4, tr.y + 1))
            if fx.VRNG.random() < 0.5:
                self.parts.items.append(fx.Particle(p[0], p[1], -math.cos(psi) * 20, math.sin(psi) * 20,
                                                    0.8, 0.8, (220, 240, 255), 2, "wake", grow=6))
        for prt in self.parts.items:
            f = prt.life / prt.max_life
            pygame.draw.circle(screen, T.lerp(T.MID, (220, 240, 255), f), (prt.x, prt.y), max(1, int(prt.size)), 1)
        # banner
        if self.banner and self.t - self.banner[3] < 4.0:
            age = self.t - self.banner[3]
            a = min(1.0, age * 4) * min(1.0, (4.0 - age) * 2)
            t1, t2, col, _ = self.banner
            b = pygame.Surface((rect.w * 0.62, 84), pygame.SRCALPHA)
            pygame.draw.rect(b, (8, 16, 26, int(230 * a)), b.get_rect(), border_radius=14)
            pygame.draw.rect(b, (*col, int(255 * a)), b.get_rect(), 2, border_radius=14)
            i1 = T.font(26, True).render(t1, True, T.TEXT); i1.set_alpha(int(255 * a))
            i2 = T.font(20, True).render(t2, True, col); i2.set_alpha(int(255 * a))
            b.blit(i1, (b.get_width() / 2 - i1.get_width() / 2, 10))
            b.blit(i2, (b.get_width() / 2 - i2.get_width() / 2, 46))
            screen.blit(b, (rect.centerx - b.get_width() / 2, rect.y + 18))
        screen.set_clip(None)
        self.draw_panel(screen, panel)

    def draw_panel(self, screen, rect):
        g = self.game
        glass(screen, rect)
        x0, y = rect.x + 16, rect.y + 14
        text(screen, "MODE A  |  EXACT GRAPH GAME", (x0, y), 12, T.ACCENT, True)
        y += 22
        text(screen, "Braess paradox at the harbour", (x0, y), 20, T.TEXT, True)
        y += 30
        mode = "MARGINAL-COST (tolled)" if self.marginal else "SELFISH travel time"
        text(screen, f"costs: {mode}", (x0, y), 12, T.WARN if self.marginal else T.MUTED, True)
        text(screen, f"shortcut A->B: {'OPEN' if self.shortcut else 'CLOSED'}", (rect.right - 16, y), 12,
             T.GOOD if self.shortcut else T.BAD, True, "tr")
        y += 24
        # per-boat table
        loads = g.loads(self.profile)
        for i in range(4):
            r = pygame.Rect(x0, y, rect.w - 32, 26)
            glass(screen, r, 120, 6)
            col = T.BOAT_COLORS[i]
            pygame.draw.rect(screen, col, (r.x, r.y + 4, 4, r.h - 8))
            text(screen, f"B{i + 1}", (r.x + 12, r.y + 5), 13, col, True)
            text(screen, g.route_name(self.profile[i]), (r.x + 50, r.y + 5), 13, T.TEXT, True)
            ci = g.private_cost(self.profile, i)
            s = f"time c_i = {fr(ci)} min"
            if self.marginal:
                s += f"   pays {fr(g.private_cost(self.profile, i, g.marginal_cost))}"
            text(screen, s, (r.right - 8, r.y + 6), 12, T.TEXT, False, "tr")
            y += 30
        y += 6
        P, C = self.phi(), g.team_cost(self.profile)
        text(screen, "Phi (potential)" if not self.marginal else "Phi_m (tolled potential)", (x0, y), 11, T.ACCENT, True)
        text(screen, "C = team cost", (rect.centerx + 10, y), 11, (255, 140, 140), True)
        y += 14
        text(screen, fr(P), (x0, y), 30, T.ACCENT, True)
        text(screen, fr(C), (rect.centerx + 10, y), 30, (255, 140, 140), True)
        text(screen, f"optimum {fr(self.opt)}", (rect.right - 16, y + 12), 11, T.MUTED, False, "tr")
        y += 44
        # chart
        cr = pygame.Rect(x0, y, rect.w - 32, 150)
        glass(screen, cr, 150, 8)
        hist = self.history
        allv = [float(v) for h in hist for v in h] + [float(self.opt)]
        lo, hi = min(allv) - 2, max(allv) + 2
        n = max(2, len(hist))
        def P_(k, v):
            return (cr.x + 30 + (cr.w - 44) * k / max(1, n - 1), cr.bottom - 18 - (cr.h - 34) * (float(v) - lo) / (hi - lo))
        yo = P_(0, self.opt)[1]
        for xx in range(cr.x + 30, cr.right - 14, 8):
            pygame.draw.line(screen, T.MUTED, (xx, yo), (xx + 4, yo), 1)
        text(screen, "OPT", (cr.x + 4, yo - 7), 9, T.MUTED, True)
        for idx, colr in ((0, T.ACCENT), (1, (255, 120, 120))):
            pts = [P_(k, h[idx]) for k, h in enumerate(hist)]
            if len(pts) >= 2:
                pygame.draw.lines(screen, colr, False, pts, 3)
            for p in pts:
                pygame.draw.circle(screen, colr, p, 4)
        text(screen, "move #", (cr.right - 8, cr.bottom - 14), 9, T.MUTED, False, "tr")
        pygame.draw.line(screen, T.ACCENT, (cr.right - 150, cr.y + 22), (cr.right - 130, cr.y + 22), 3)
        text(screen, "Phi", (cr.right - 126, cr.y + 15), 10, T.ACCENT, True)
        pygame.draw.line(screen, (255, 120, 120), (cr.right - 90, cr.y + 22), (cr.right - 70, cr.y + 22), 3)
        text(screen, "C (team)", (cr.right - 66, cr.y + 15), 10, (255, 120, 120), True)
        text(screen, "Phi falls every move; C need not", (cr.x + 30, cr.y + 4), 10, T.MUTED)
        y += 160
        # explanation of last move with exact identity check
        if self.last:
            d = self.last
            i = d["i"]
            dphi = d["P1"] - d["P0"]; dci = d["c_new"] - d["c_old"]
            lines = [
                (f"B{i + 1}: {g.route_name(d['old'])} -> {g.route_name(d['new'])}", T.BOAT_COLORS[i], True),
                (f"own cost  {fr(d['c_old'])} -> {fr(d['c_new'])}   (d c_i = {fr(dci)})", T.TEXT, False),
                (f"team cost {fr(d['C0'])} -> {fr(d['C1'])}   (d C = {fr(d['C1'] - d['C0'])})",
                 T.BAD if d['C1'] > d['C0'] else T.GOOD, True),
                (f"check: d Phi = {fr(dphi)} = d c_i  {'OK' if dphi == dci else 'FAIL'}",
                 T.GOOD if dphi == dci else T.BAD, False),
            ]
            for s, c, b in lines:
                text(screen, s, (x0, y), 13, c, b); y += 19
        else:
            text(screen, "press SPACE: one boat best-responds", (x0, y), 13, T.MUTED); y += 19
        y += 8
        A = self.analysis
        text(screen, f"exhaustive: {len(A.equilibria)} pure NE of {len(g.routes) ** 4} profiles", (x0, y), 11, T.MUTED); y += 16
        text(screen, f"worst NE C = {fr(A.worst_eq_cost)}   OPT = {fr(A.optimum_cost)}   PoA = {fr(A.price_of_anarchy)}",
             (x0, y), 11, T.TEXT, True); y += 22
        if self.show_cycle:
            r = pygame.Rect(x0, y, rect.w - 32, 92)
            glass(screen, r, 170, 8, T.WARN)
            nA = [len(g.routes)] * 4
            Imax = max(abs(I) for _, I in four_cycle_sums(nA, lambda a, i: g.private_cost(a, i, self.ecost())))
            mp = [I for _, I in four_cycle_sums([2, 2], matching_pennies_cost)]
            text(screen, "4-cycle test (Monderer-Shapley)", (r.x + 10, r.y + 6), 12, T.WARN, True)
            text(screen, f"this game: max |circulation| = {fr(Imax)}  -> exact potential", (r.x + 10, r.y + 28), 11, T.TEXT)
            text(screen, f"matching pennies: circulation = {fr(mp[0])}  -> NO potential", (r.x + 10, r.y + 46), 11, T.TEXT)
            text(screen, "(like a closed line integral of a conservative field)", (r.x + 10, r.y + 66), 10, T.MUTED)
            y += 100
        keys = ["SPACE step   A autoplay   M marginal tolls", "O open/close shortcut   R reset   4 cycle test",
                "TAB next mode   H help"]
        for k, s in enumerate(keys):
            text(screen, s, (x0, rect.bottom - 18 * (len(keys) - k) - 6), 11, T.MUTED)
