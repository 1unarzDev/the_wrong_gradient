"""Renders a Simulation (read-only) into a viewport: ocean, course, boats, comms, FX, HUD."""
from __future__ import annotations

import math
from typing import Dict, List, Optional

import numpy as np
import pygame

from ..navigation import graph_eta
from ..policies import POLICY_INFO
from ..tasks import RADIUS
from . import fx
from . import theme as T

TYPE_LABEL = {"gate": "GATE", "inspect": "INSPECT", "dock": "DOCK", "sample": "SAMPLE"}


class Camera:
    def __init__(self, rect: pygame.Rect, world, zoom=1.0):
        self.rect = pygame.Rect(rect)
        self.world = world
        self.fit = min(self.rect.w / world.width, self.rect.h / world.height) * 0.97
        self.zoom = zoom
        self.cx, self.cy = world.width / 2, world.height / 2

    @property
    def scale(self):
        return self.fit * self.zoom

    @property
    def vx(self): return self.rect.x

    @property
    def vy(self): return self.rect.y

    @property
    def vw(self): return self.rect.w

    @property
    def vh(self): return self.rect.h

    @property
    def boat_exag(self):
        return max(1.0, 30.0 / (1.8 * self.scale))

    def to_screen(self, x, y):
        s = self.scale
        return (int(self.rect.x + self.rect.w / 2 + (x - self.cx) * s),
                int(self.rect.y + self.rect.h / 2 - (y - self.cy) * s))

    def to_world(self, X, Y):
        s = self.scale
        return (self.cx + (X - self.rect.x - self.rect.w / 2) / s,
                self.cy - (Y - self.rect.y - self.rect.h / 2) / s)


def draw_icon(dst, kind, c, r, color):
    x, y = c
    if kind == "gate":
        pygame.draw.line(dst, color, (x - r * 0.45, y - r * 0.5), (x - r * 0.45, y + r * 0.5), 3)
        pygame.draw.line(dst, color, (x + r * 0.45, y - r * 0.5), (x + r * 0.45, y + r * 0.5), 3)
        pygame.draw.polygon(dst, color, [(x - r * 0.2, y - r * 0.25), (x + r * 0.25, y), (x - r * 0.2, y + r * 0.25)])
    elif kind == "inspect":
        pygame.draw.circle(dst, color, (x - r * 0.1, y - r * 0.1), r * 0.38, 2)
        pygame.draw.line(dst, color, (x + r * 0.18, y + r * 0.18), (x + r * 0.5, y + r * 0.5), 3)
    elif kind == "dock":
        pygame.draw.line(dst, color, (x, y - r * 0.5), (x, y + r * 0.45), 3)
        pygame.draw.arc(dst, color, (x - r * 0.5, y - r * 0.2, r, r * 0.7), math.pi, 2 * math.pi, 3)
        pygame.draw.line(dst, color, (x - r * 0.3, y - r * 0.3), (x + r * 0.3, y - r * 0.3), 2)
    elif kind == "sample":
        pts = [(x, y - r * 0.55), (x + r * 0.38, y + r * 0.12), (x, y + r * 0.5), (x - r * 0.38, y + r * 0.12)]
        pygame.draw.polygon(dst, color, pts, 0)


class MissionView:
    def __init__(self, sim, rect: pygame.Rect, label: str = "", label_right: bool = False):
        self.sim = sim
        self.label_right = label_right
        self.cam = Camera(rect, sim.world)
        self.label = label
        self.static: Optional[pygame.Surface] = None
        self.static_scale = None
        self.caustics = fx.caustics_texture(intensity=0.55)
        self.caustics2 = fx.caustics_texture(size=384, seed=8, intensity=0.4)
        self.caus_layer = pygame.Surface(rect.size)
        self.mask = None
        self.land = fx.land_texture()
        self.flow = fx.FlowField(sim.world, n=int(700 * max(1.0, sim.world.width * sim.world.height / 26000) ** 0.5))
        self.parts = fx.Particles()
        self.ev_idx = 0
        self.trail = pygame.Surface(rect.size, pygame.SRCALPHA)
        self.layer = pygame.Surface(rect.size, pygame.SRCALPHA)
        self.cam_key = None
        self.shake = 0.0
        self.history: List[tuple] = []           # (t, welfare, points)
        self.show_sensors = False
        self.show_graph = False
        self.show_flow = True
        self.task_pop: Dict[int, float] = {}     # release animation start (vis time)
        self.flash: Dict[int, float] = {}
        self.vis_t = 0.0
        self.last_t = 0.0
        self.vignette = self._make_vignette(rect.size)

    def _make_vignette(self, size):
        w, h = size
        yy, xx = np.mgrid[0:h, 0:w]
        d = np.hypot((xx - w / 2) / (w / 2), (yy - h / 2) / (h / 2))
        a = np.clip((d - 0.75) / 0.6, 0, 1) ** 1.6 * 150
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        arr = pygame.surfarray.pixels_alpha(surf)
        arr[:] = a.T.astype(np.uint8)
        del arr
        return surf

    def resize(self, rect):
        self.cam.rect = pygame.Rect(rect)
        self.cam.fit = min(rect.w / self.sim.world.width, rect.h / self.sim.world.height) * 0.97
        self.trail = pygame.Surface(rect.size, pygame.SRCALPHA)
        self.layer = pygame.Surface(rect.size, pygame.SRCALPHA)
        self.caus_layer = pygame.Surface(rect.size)
        self.vignette = self._make_vignette(rect.size)
        self.static = None

    # -------------------------------------------------------------------------------
    def consume_events(self):
        sim = self.sim
        for e in sim.events[self.ev_idx:]:
            if e.kind == "complete":
                col = T.BOAT_COLORS[e.boat % 16]
                self.parts.burst(e.x, e.y, col, n=70, speed=10)
                self.parts.text(e.x, e.y + 4, f"+{int(e.value)}", (255, 236, 140), life=2.4, size=1.7)
                self.parts.text(e.x, e.y + 1.5, f"B{e.boat + 1} {self.sim.tasks[e.task].kind.upper()}", col, life=2.0, size=0.8)
                self.shake = max(self.shake, 0.25)
                self.flash[e.task] = self.vis_t
            elif e.kind == "collision":
                self.parts.sparks(e.x, e.y, (255, 150, 60), 40)
                self.parts.text(e.x, e.y + 2, "COLLISION", T.BAD, life=1.5, size=0.8)
                self.shake = max(self.shake, 0.4)
            elif e.kind == "obstacle":
                self.parts.sparks(e.x, e.y, (255, 200, 120), 18)
            elif e.kind == "redundant":
                self.parts.smoke(e.x, e.y)
                self.parts.text(e.x, e.y + 3, "redundant", T.MUTED, life=1.4, size=0.7)
            elif e.kind == "expire":
                self.parts.smoke(e.x, e.y, (200, 80, 80), 14)
                self.parts.text(e.x, e.y + 3, "expired", (255, 120, 120), life=1.6, size=0.75)
        self.ev_idx = len(sim.events)

    def update(self, real_dt, sim_dt):
        self.vis_t += real_dt
        self.consume_events()
        sim = self.sim
        # visual particle time follows sim time (slow-mo looks slow), clamped
        pdt = min(max(sim_dt, 0.0), 0.5)
        if pdt > 0:
            for i in range(sim.n):
                x, y, psi, v, _ = sim.S[:, i]
                ex = self.cam.boat_exag
                back = 0.85 * ex
                for side in (-0.32, 0.32):
                    sx = x - back * math.cos(psi) - side * ex * math.sin(psi)
                    sy = y - back * math.sin(psi) + side * ex * math.cos(psi)
                    if fx.VRNG.random() < min(1.0, pdt * 14):
                        self.parts.wake(sx, sy, psi, abs(v))
                    thr = sim.TL[i] if side > 0 else sim.TR[i]
                    if fx.VRNG.random() < min(1.0, pdt * 20):
                        self.parts.prop(sx, sy, psi, abs(float(thr)))
            self.parts.update(pdt)
            self.flow.update(sim.t, pdt, speedup=7.0)
        else:
            self.parts.update(0.0)
        self.shake = max(0.0, self.shake - real_dt)
        if sim.t - self.last_t >= 1.0 or not self.history:
            m = self.live_metrics()
            self.history.append((sim.t, m["welfare"], m["points"]))
            self.last_t = sim.t
        for tk in sim.tasks:
            if tk.release <= sim.t and tk.id not in self.task_pop:
                self.task_pop[tk.id] = self.vis_t

    def live_metrics(self):
        sim, cfg = self.sim, self.sim.cfg
        pts = sum(tk.value for tk in sim.tasks if tk.completed_by is not None)
        coll = sum(1 for e in sim.events if e.kind in ("collision", "obstacle"))
        en = float(sim.energy.sum())
        return dict(points=pts, collisions=coll, energy=en,
                    welfare=pts - cfg.w_energy * en - cfg.w_collision * coll,
                    completed=sum(1 for tk in sim.tasks if tk.completed_by is not None),
                    expired=sum(1 for tk in sim.tasks if tk.completed_by is None and sim.t > tk.deadline),
                    redundant=sum(1 for e in sim.events if e.kind == "redundant"))

    # -------------------------------------------------------------------------------
    def draw(self, screen):
        sim, cam = self.sim, self.cam
        W = sim.world
        vp = cam.rect
        screen.set_clip(vp)
        # surrounding coastline (outside the arena)
        lw, lh = self.land.get_size()
        for X in range(vp.left, vp.right, lw):
            for Y in range(vp.top, vp.bottom, lh):
                screen.blit(self.land, (X, Y))
        sc = round(cam.scale, 3)
        if self.static is None or self.static_scale != sc:
            self.static = fx.render_static(W, cam.scale)
            self.static_scale = sc
            self.mask = fx.water_mask(W, cam.scale)
        ox, oy = cam.to_screen(0, W.height)
        shx = shy = 0
        if self.shake > 0:
            shx = int(fx.VRNG.uniform(-1, 1) * 6 * self.shake); shy = int(fx.VRNG.uniform(-1, 1) * 6 * self.shake)
        ar = pygame.Rect(ox + shx, oy + shy, self.static.get_width(), self.static.get_height())
        for k, (col, a) in enumerate(((T.SAND_DARK, 255), (T.SAND, 255), (T.FOAM, 120))):
            g = int(cam.scale * (2.2 - 0.7 * k))
            pygame.draw.rect(screen, col, ar.inflate(2 * g, 2 * g), border_radius=int(cam.scale * 3))
        screen.blit(self.static, ar.topleft)
        # caustics shimmer: two counter-drifting layers, masked to water, added on top
        CL = self.caus_layer
        if CL.get_size() != vp.size:
            CL = self.caus_layer = pygame.Surface(vp.size)
        CL.fill((0, 0, 0))
        ar_local = ar.move(-vp.x, -vp.y)
        CL.set_clip(ar_local)
        for tex, sx_, sy_ in ((self.caustics, 9, 5), (self.caustics2, -6, 7)):
            tw, th = tex.get_size()
            offx = int(self.vis_t * sx_) % tw; offy = int(self.vis_t * sy_) % th
            for X in range(ar_local.left - offx, ar_local.right, tw):
                for Y in range(ar_local.top - offy, ar_local.bottom, th):
                    CL.blit(tex, (X, Y), special_flags=pygame.BLEND_ADD)
        CL.set_clip(None)
        CL.blit(self.mask, ar_local.topleft, special_flags=pygame.BLEND_MULT)
        screen.blit(CL, vp.topleft, special_flags=pygame.BLEND_ADD)

        key = (cam.cx, cam.cy, sc, vp.topleft, vp.size)
        if key != self.cam_key:
            self.trail.fill((0, 0, 0, 0)); self.cam_key = key
        if self.show_flow:
            self.trail.fill((0, 0, 0, 9), special_flags=pygame.BLEND_RGBA_SUB)
            loc = Camera(pygame.Rect(0, 0, vp.w, vp.h), W); loc.cx, loc.cy, loc.zoom, loc.fit = cam.cx, cam.cy, cam.zoom, cam.fit
            self.flow.draw(self.trail, loc)
            screen.blit(self.trail, vp.topleft)

        L = self.layer
        L.fill((0, 0, 0, 0))
        loc = Camera(pygame.Rect(0, 0, vp.w, vp.h), W); loc.cx, loc.cy, loc.zoom, loc.fit = cam.cx, cam.cy, cam.zoom, cam.fit
        self._draw_channels(L, loc)
        fx.draw_particles(L, self.parts, loc, layer="wake")
        self._draw_tasks(L, loc)
        self._draw_paths(L, loc)
        self._draw_comms(L, loc)
        screen.blit(L, vp.topleft)
        self._draw_boats(screen, cam)
        L.fill((0, 0, 0, 0))
        adds = fx.draw_particles(L, self.parts, loc, layer="fx")
        screen.blit(L, vp.topleft)
        for col, (X, Y), r, f in adds:
            fx.blit_glow(screen, col, (X + vp.x, Y + vp.y), r * 2, 0.9 * f + 0.1)
            pygame.draw.circle(screen, (255, 255, 240), (X + vp.x, Y + vp.y), max(1, r // 3))
        screen.blit(self.vignette, vp.topleft)
        if self.label:
            img = T.font(20, True).render(self.label, True, T.TEXT)
            bg = pygame.Surface((img.get_width() + 24, img.get_height() + 10), pygame.SRCALPHA)
            bg.fill((8, 18, 28, 200))
            bx = vp.x + 12 if not self.label_right else vp.right - bg.get_width() - 12
            screen.blit(bg, (bx, vp.y + 12)); screen.blit(img, (bx + 12, vp.y + 17))
        screen.set_clip(None)

    def _draw_channels(self, L, cam):
        sim = self.sim
        for ch in sim.world.channels:
            occ = any(ch.contains(sim.S[0, i], sim.S[1, i], pad=0.5) for i in range(sim.n))
            col = T.BAD if occ else T.GOOD
            for (x, sgn) in ((ch.x0 - 1.5, -1), (ch.x1 + 1.5, 1)):
                a = cam.to_screen(x, ch.y0 + 0.6); b = cam.to_screen(x, ch.y1 - 0.6)
                pygame.draw.line(L, (*col, 120), a, b, 2)
                # beacon lights on both channel walls
                for yy in (ch.y0 - 0.6, ch.y1 + 0.6):
                    p = cam.to_screen(x, yy)
                    pulse = 0.6 + 0.4 * math.sin(self.vis_t * 4 + x)
                    pygame.draw.circle(L, (*col, int(200 * pulse)), p, max(2, int(cam.scale * 0.5)))
            c = cam.to_screen(*ch.center)
            img = T.font(11, True).render("1-LANE", True, (*T.TEXT,))
            img.set_alpha(150)
            L.blit(img, (c[0] - img.get_width() / 2, c[1] - img.get_height() / 2))

    def _draw_tasks(self, L, cam):
        sim = self.sim
        t = sim.t
        s = cam.scale
        for tk in sim.tasks:
            if tk.release > t:
                continue
            done = tk.completed_by is not None
            expired = (not done) and t > tk.deadline
            col = T.TASK_COLORS[tk.kind]
            pop = min(1.0, (self.vis_t - self.task_pop.get(tk.id, -9)) / 0.5)
            popk = 1 + 0.35 * math.sin(pop * math.pi) if pop < 1 else 1.0
            if tk.kind == "gate":
                (rx, ry), (gx, gy) = tk.buoys()
                bob = 1 + 0.12 * math.sin(self.vis_t * 3 + tk.id)
                for (bx, by), bc in (((rx, ry), T.RED_BUOY), ((gx, gy), T.GREEN_BUOY)):
                    p = cam.to_screen(bx, by)
                    rr = max(3, int(0.55 * s * bob * 1.6))
                    pygame.draw.circle(L, (0, 0, 0, 90), (p[0] + 2, p[1] + 2), rr)
                    pygame.draw.circle(L, (*bc, 255), p, rr)
                    pygame.draw.circle(L, (255, 255, 255, 200), (p[0] - rr // 3, p[1] - rr // 3), max(1, rr // 3))
                if not done and not expired:
                    a = cam.to_screen(rx, ry); b = cam.to_screen(gx, gy)
                    n = 8
                    for k in range(n):
                        if k % 2 == 0:
                            p1 = (a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n)
                            p2 = (a[0] + (b[0] - a[0]) * (k + 1) / n, a[1] + (b[1] - a[1]) * (k + 1) / n)
                            pygame.draw.line(L, (*col, 160), p1, p2, 2)
                    # chevrons showing required direction
                    for off in (-5.0, -2.5):
                        cx = tk.x + off * math.cos(tk.heading); cy = tk.y + off * math.sin(tk.heading)
                        ph = (self.vis_t * 2 + off) % 1.0
                        a_ = int(180 * (0.4 + 0.6 * ph))
                        hx, hy = math.cos(tk.heading), math.sin(tk.heading)
                        px_, py_ = -hy, hx
                        tip = cam.to_screen(cx + hx * 0.9, cy + hy * 0.9)
                        l1 = cam.to_screen(cx - px_ * 1.2, cy - py_ * 1.2)
                        l2 = cam.to_screen(cx + px_ * 1.2, cy + py_ * 1.2)
                        pygame.draw.lines(L, (*col, a_), False, [l1, tip, l2], 2)
            elif not done:
                rr = RADIUS[tk.kind]
                p = cam.to_screen(tk.x, tk.y)
                pulse = 0.5 + 0.5 * math.sin(self.vis_t * 2.5 + tk.id)
                pygame.draw.circle(L, (*col, 30 + int(25 * pulse)), p, max(3, int(rr * s)))
                pygame.draw.circle(L, (*col, 120), p, max(3, int(rr * s)), 1)
            # badge
            bxy = cam.to_screen(tk.x, tk.y + (5.5 if tk.kind == "gate" else 4.5))
            R = int(13 * popk)
            if done:
                fl = max(0.0, 1 - (self.vis_t - self.flash.get(tk.id, -9)) / 1.2)
                pygame.draw.circle(L, (20, 60, 40, 200), bxy, R)
                pygame.draw.circle(L, (*T.GOOD, 255), bxy, R, 2)
                pygame.draw.lines(L, T.GOOD, False, [(bxy[0] - 6, bxy[1]), (bxy[0] - 1, bxy[1] + 5), (bxy[0] + 7, bxy[1] - 5)], 3)
                if fl > 0:
                    pygame.draw.circle(L, (255, 255, 255, int(200 * fl)), bxy, int(R + 14 * (1 - fl)), 2)
                continue
            if expired:
                pygame.draw.circle(L, (40, 30, 34, 160), bxy, R)
                pygame.draw.circle(L, (130, 70, 70, 180), bxy, R, 2)
                pygame.draw.line(L, (170, 80, 80), (bxy[0] - 5, bxy[1] - 5), (bxy[0] + 5, bxy[1] + 5), 2)
                pygame.draw.line(L, (170, 80, 80), (bxy[0] - 5, bxy[1] + 5), (bxy[0] + 5, bxy[1] - 5), 2)
                continue
            pygame.draw.circle(L, (0, 0, 0, 110), (bxy[0] + 2, bxy[1] + 3), R + 3)
            pygame.draw.circle(L, (12, 24, 36, 235), bxy, R + 2)
            frac = max(0.0, (tk.deadline - t) / max(1e-6, tk.deadline - tk.release))
            ring = T.GOOD if frac > 0.5 else (T.WARN if frac > 0.2 else T.BAD)
            if frac < 0.2:
                ring = T.lerp(T.BAD, (255, 255, 255), 0.5 + 0.5 * math.sin(self.vis_t * 10))
            rect = pygame.Rect(0, 0, 2 * R + 8, 2 * R + 8); rect.center = bxy
            pygame.draw.arc(L, (*ring, 255), rect, math.pi / 2, math.pi / 2 + 2 * math.pi * frac, 3)
            draw_icon(L, tk.kind, bxy, R, col)
            # claimants: coloured pips
            claim = [i for i, m in enumerate(self.sim.minds) if m.claim == tk.id]
            for k, i in enumerate(claim):
                ang = -math.pi / 2 + (k - (len(claim) - 1) / 2) * 0.55
                pp = (bxy[0] + (R + 9) * math.cos(ang), bxy[1] - (R + 9) * math.sin(ang) * -1)
                pygame.draw.circle(L, T.BOAT_COLORS[i % 16], pp, 4)
                pygame.draw.circle(L, (0, 0, 0), pp, 4, 1)
            vimg = T.font(12, True).render(f"{tk.value}", True, T.TEXT)
            L.blit(vimg, (bxy[0] - vimg.get_width() / 2, bxy[1] + R + 3))
            if len(claim) >= 2:
                wimg = T.font(11, True).render("CONTESTED", True, T.WARN)
                L.blit(wimg, (bxy[0] - wimg.get_width() / 2, bxy[1] - R - 22))

    def _draw_paths(self, L, cam):
        sim = self.sim
        dash_off = (self.vis_t * 30) % 16
        for i, m in enumerate(sim.minds):
            g = m.guidance
            if g is None:
                continue
            col = T.BOAT_COLORS[i % 16]
            pts = [cam.to_screen(sim.S[0, i], sim.S[1, i])] + [cam.to_screen(*w) for w in g.wps[g.seg + 1:]]
            if len(pts) < 2:
                continue
            # dashed animated polyline
            acc = -dash_off
            for a, b in zip(pts, pts[1:]):
                L_ = math.hypot(b[0] - a[0], b[1] - a[1])
                if L_ < 1:
                    continue
                d = acc
                while d < L_:
                    s0 = max(d, 0); s1 = min(d + 8, L_)
                    if s1 > s0:
                        p0 = (a[0] + (b[0] - a[0]) * s0 / L_, a[1] + (b[1] - a[1]) * s0 / L_)
                        p1 = (a[0] + (b[0] - a[0]) * s1 / L_, a[1] + (b[1] - a[1]) * s1 / L_)
                        pygame.draw.line(L, (*col, 170 if m.claim is not None else 70), p0, p1, 2)
                    d += 16
                acc = d - L_ - 16
            end = pts[-1]
            if m.claim is not None:
                r = 6 + 2 * math.sin(self.vis_t * 6)
                pygame.draw.circle(L, (*col, 200), end, int(r), 2)
            if self.show_graph and m.claim is not None:
                tk = sim.tasks[m.claim]
                p = m.pred
                if p:
                    el = sim.t - p["t"]
                    txt = f"g {p['eta_graph']:.0f}s | c {p['eta_control']:.0f}s | t {el:.0f}s"
                    img = T.font(11).render(txt, True, col)
                    L.blit(img, (end[0] + 10, end[1] - 6))

    def _draw_comms(self, L, cam):
        sim = self.sim
        t = sim.t
        n = sim.n
        for i in range(n):
            for j in range(i + 1, n):
                mi, mj = sim.minds[i].beliefs.get(j), sim.minds[j].beliefs.get(i)
                ages = [t - m.t_sent for m in (mi, mj) if m is not None]
                if not ages:
                    continue
                age = min(ages)
                a = math.exp(-age / 4.0)
                if a < 0.06:
                    continue
                p = cam.to_screen(sim.S[0, i], sim.S[1, i]); q = cam.to_screen(sim.S[0, j], sim.S[1, j])
                pygame.draw.line(L, (120, 220, 255, int(70 * a)), p, q, 1)
        # packets in flight
        for deliver_t, r, msg in sim.net.in_flight:
            span = max(1e-3, deliver_t - msg.t_sent)
            f = min(1.0, max(0.0, (t - msg.t_sent) / span))
            a = cam.to_screen(sim.S[0, msg.sender], sim.S[1, msg.sender])
            b = cam.to_screen(sim.S[0, r], sim.S[1, r])
            p = (a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f)
            col = T.BOAT_COLORS[msg.sender % 16]
            pygame.draw.circle(L, (*col, 230), p, 3)
            pygame.draw.circle(L, (255, 255, 255, 200), p, 1)
        # dropped packets: red fizzles near the sender for 0.8 s
        keep_from = 0
        for k in range(len(sim.net.dropped_events) - 1, -1, -1):
            ts, s_, r = sim.net.dropped_events[k]
            age = t - ts
            if age > 0.8:
                break
            a = cam.to_screen(sim.S[0, s_], sim.S[1, s_]); b = cam.to_screen(sim.S[0, r], sim.S[1, r])
            f = 0.15 + 0.35 * age / 0.8
            p = (a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f)
            al = int(220 * (1 - age / 0.8))
            pygame.draw.line(L, (255, 90, 90, al), (p[0] - 3, p[1] - 3), (p[0] + 3, p[1] + 3), 2)
            pygame.draw.line(L, (255, 90, 90, al), (p[0] - 3, p[1] + 3), (p[0] + 3, p[1] - 3), 2)
        if len(sim.net.dropped_events) > 4000:
            del sim.net.dropped_events[:2000]

    def _draw_boats(self, screen, cam):
        sim = self.sim
        Lpx = int(1.8 * cam.scale * cam.boat_exag)
        for i in range(sim.n):
            x, y, psi, v, r = sim.S[:, i]
            col = T.BOAT_COLORS[i % 16]
            p = cam.to_screen(x, y)
            m = sim.minds[i]
            fx.blit_glow(screen, tuple(int(c * 0.5) for c in col), p, int(Lpx * 1.1), 0.6)
            if self.show_sensors:
                pygame.draw.circle(screen, (*col, 40), p, int(sim.cfg.sensor_range_m * cam.scale), 1)
            fx.draw_boat(screen, p, psi, col, Lpx)
            # heading arrow
            hx, hy = math.cos(psi), math.sin(psi)
            tip = (p[0] + hx * Lpx * 0.95, p[1] - hy * Lpx * 0.95)
            pygame.draw.line(screen, (255, 255, 255), (p[0] + hx * Lpx * 0.55, p[1] - hy * Lpx * 0.55), tip, 2)
            # id tag
            tag = T.font(12, True).render(f"B{i + 1}", True, (10, 14, 20))
            tr = pygame.Rect(0, 0, tag.get_width() + 8, tag.get_height() + 2)
            tr.center = (p[0], p[1] - Lpx * 0.75 - 6)
            pygame.draw.rect(screen, col, tr, border_radius=6)
            screen.blit(tag, (tr.x + 4, tr.y + 1))
            st = "HOLD" if m.holding else ("AVOID" if m.avoiding else None)
            if st:
                sc = T.WARN if st == "HOLD" else T.BAD
                img = T.font(10, True).render(st, True, sc)
                screen.blit(img, (tr.right + 4, tr.y + 1))


# ---------------------------------------------------------------------------------
# HUD side panel
# ---------------------------------------------------------------------------------
def glass(screen, rect, alpha=215, radius=12, edge=T.PANEL_EDGE):
    s = pygame.Surface(rect.size, pygame.SRCALPHA)
    pygame.draw.rect(s, (*T.PANEL, alpha), s.get_rect(), border_radius=radius)
    pygame.draw.rect(s, (*edge, 200), s.get_rect(), 1, border_radius=radius)
    screen.blit(s, rect.topleft)


def text(screen, s, pos, size=14, color=T.TEXT, bold=False, anchor="tl"):
    img = T.font(size, bold).render(str(s), True, color)
    r = img.get_rect()
    setattr(r, {"tl": "topleft", "tr": "topright", "c": "center", "ml": "midleft", "mr": "midright"}[anchor], pos)
    screen.blit(img, r)
    return r


def sparkline(screen, rect, series, color, label, fmt="{:.0f}"):
    glass(screen, rect, 160, 8)
    if len(series) < 2:
        return
    ys = np.array(series, float)
    lo, hi = min(0.0, ys.min()), max(1.0, ys.max())
    pts = [(rect.x + 8 + (rect.w - 16) * k / (len(ys) - 1),
            rect.bottom - 8 - (rect.h - 26) * (v - lo) / (hi - lo)) for k, v in enumerate(ys)]
    poly = pts + [(pts[-1][0], rect.bottom - 8), (pts[0][0], rect.bottom - 8)]
    s = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
    pygame.draw.polygon(s, (*color, 45), poly)
    screen.blit(s, (0, 0))
    pygame.draw.lines(screen, color, False, pts, 2)
    pygame.draw.circle(screen, color, pts[-1], 4)
    text(screen, label, (rect.x + 8, rect.y + 4), 11, T.MUTED, True)
    text(screen, fmt.format(ys[-1]), (rect.right - 8, rect.y + 3), 13, color, True, "tr")


def draw_panel(screen, rect, view: MissionView, extra_lines=()):
    sim = view.sim
    cfg = sim.cfg
    glass(screen, rect)
    x0, y = rect.x + 16, rect.y + 14
    text(screen, "FLEET STATUS", (x0, y), 12, T.ACCENT, True)
    text(screen, f"t = {sim.t:6.1f} / {cfg.episode_s:.0f} s", (rect.right - 16, y), 12, T.MUTED, False, "tr")
    y += 22
    text(screen, f"{cfg.policy}", (x0, y), 22, T.TEXT, True)
    y += 28
    info = POLICY_INFO.get(cfg.policy, "")
    text(screen, info if len(info) < 58 else info[:56] + "..", (x0, y), 11, T.MUTED)
    y += 22
    cm = {"ideal": T.GOOD, "degraded": T.WARN, "none": T.BAD}[cfg.comm_mode]
    pill = pygame.Rect(x0, y, 150, 20)
    pygame.draw.rect(screen, (*cm, ), pill, 1, border_radius=10)
    text(screen, f"COMMS: {cfg.comm_mode.upper()}", pill.center, 11, cm, True, "c")
    sent, dl = sim.net.sent, sim.net.delivered
    text(screen, f"delivered {dl}/{sent}", (pill.right + 10, y + 3), 11, T.MUTED)
    y += 30
    m = view.live_metrics()
    # big welfare number
    text(screen, "TEAM WELFARE  W", (x0, y), 11, T.MUTED, True)
    y += 14
    wcol = T.GOOD if m["welfare"] >= 0 else T.BAD
    text(screen, f"{m['welfare']:+.1f}", (x0, y), 34, wcol, True)
    tot = sum(tk.value for tk in sim.tasks)
    text(screen, f"points {m['points']}/{tot}", (rect.right - 16, y + 4), 13, T.TEXT, False, "tr")
    text(screen, f"energy -{cfg.w_energy * m['energy']:.1f}   contacts -{cfg.w_collision * m['collisions']:.0f}",
         (rect.right - 16, y + 24), 11, T.MUTED, False, "tr")
    y += 48
    sparkline(screen, pygame.Rect(x0, y, rect.w - 32, 64), [h[1] for h in view.history], T.ACCENT, "W(t)")
    y += 74
    # task chips
    cols = 4
    chip_w = (rect.w - 32 - (cols - 1) * 6) // cols
    stats = [("DONE", m["completed"], T.GOOD), ("EXPIRED", m["expired"], T.BAD),
             ("REDUNDANT", m["redundant"], T.WARN), ("CONTACTS", m["collisions"], T.BAD)]
    for k, (lab, val, c) in enumerate(stats):
        r = pygame.Rect(x0 + k * (chip_w + 6), y, chip_w, 40)
        glass(screen, r, 150, 8)
        text(screen, str(val), (r.centerx, r.y + 14), 16, c, True, "c")
        text(screen, lab, (r.centerx, r.y + 31), 9, T.MUTED, True, "c")
    y += 52
    # boat cards
    text(screen, "BOATS", (x0, y), 12, T.ACCENT, True)
    y += 18
    avail = rect.bottom - y - 12 - 18 * len(extra_lines)
    ch = max(22, min(78, avail // max(1, sim.n) - 4))
    compact = ch < 60
    for i in range(sim.n):
        if y + ch > rect.bottom - 10:
            break
        mi = sim.minds[i]
        col = T.BOAT_COLORS[i % 16]
        r = pygame.Rect(x0, y, rect.w - 32, ch)
        glass(screen, r, 140, 8)
        pygame.draw.rect(screen, col, (r.x, r.y + 4, 4, r.h - 8), border_radius=2)
        text(screen, f"B{i + 1}", (r.x + 12, r.y + 4), 13, col, True)
        v = sim.S[3, i]
        if mi.claim is not None:
            tk = sim.tasks[mi.claim]
            task_s = f"{TYPE_LABEL[tk.kind]} #{tk.id}  ({tk.value} pts)"
            tcol = T.TASK_COLORS[tk.kind]
        else:
            task_s, tcol = "idle / repositioning", T.MUTED
        text(screen, task_s, (r.x + 46, r.y + 5), 12, tcol, True)
        st = "HOLD" if mi.holding else ("AVOID" if mi.avoiding else f"{v:4.2f} m/s")
        text(screen, st, (r.right - 8, r.y + 5), 11, T.WARN if mi.holding or mi.avoiding else T.MUTED, False, "tr")
        if not compact:
            p = mi.pred
            if p:
                el = sim.t - p["t"]
                text(screen, f"ETA graph {p['eta_graph']:5.1f}s  control {p['eta_control']:5.1f}s  elapsed {el:5.1f}s",
                     (r.x + 12, r.y + 25), 11, T.TEXT)
                # progress bar: elapsed vs control ETA
                bw = r.w - 24
                frac = min(1.0, el / max(1e-6, p["eta_control"]))
                pygame.draw.rect(screen, (30, 46, 60), (r.x + 12, r.y + 42, bw, 5), border_radius=3)
                pygame.draw.rect(screen, col if frac < 1 else T.BAD, (r.x + 12, r.y + 42, int(bw * frac), 5), border_radius=3)
            # message ages from teammates
            xx = r.x + 12
            text(screen, "msg age", (xx, r.y + ch - 20), 10, T.MUTED)
            xx += 52
            for j in range(sim.n):
                if j == i:
                    continue
                b = mi.beliefs.get(j)
                age = sim.t - b.t_sent if b else 99
                c = T.GOOD if age < 2 else (T.WARN if age < 6 else T.BAD)
                lab = f"{age:3.0f}s" if age < 99 else " -- "
                text(screen, f"B{j + 1}", (xx, r.y + ch - 20), 10, T.BOAT_COLORS[j % 16], True)
                text(screen, lab, (xx + 20, r.y + ch - 20), 10, c)
                xx += 56
                if xx > r.right - 50:
                    break
            text(screen, f"U={mi.utility:5.1f}", (r.right - 8, r.y + ch - 20), 10, T.MUTED, False, "tr")
        y += ch + 4
    for k, line in enumerate(extra_lines):
        text(screen, line, (x0, rect.bottom - 18 * (len(extra_lines) - k) - 6), 11, T.MUTED)
