"""Palette + fonts. Visual-only: nothing here touches simulation state or RNG."""
import pygame

BG = (6, 14, 22)
DEEP = (9, 38, 58)
MID = (14, 66, 88)
SHALLOW = (38, 120, 128)
FOAM = (220, 240, 245)
SAND = (226, 200, 146)
SAND_DARK = (190, 160, 110)
GRASS = (62, 122, 78)
GRASS_DARK = (40, 92, 60)
ROCK = (92, 86, 82)
ROCK_LIGHT = (130, 122, 114)
WOOD = (139, 100, 62)
WOOD_DARK = (96, 68, 42)

PANEL = (10, 20, 32)
PANEL_EDGE = (40, 80, 110)
TEXT = (230, 241, 255)
MUTED = (138, 164, 191)
ACCENT = (92, 225, 230)
GOOD = (128, 237, 153)
WARN = (255, 193, 69)
BAD = (255, 99, 99)
RED_BUOY = (235, 64, 52)
GREEN_BUOY = (46, 204, 113)

BOAT_COLORS = [
    (255, 107, 107), (255, 193, 69), (76, 201, 240), (128, 237, 153),
    (179, 136, 255), (247, 37, 133), (255, 159, 28), (100, 255, 218),
    (255, 230, 109), (120, 160, 255), (255, 140, 190), (160, 230, 90),
    (255, 120, 70), (90, 220, 255), (210, 160, 255), (240, 240, 240),
]

TASK_COLORS = {"gate": (92, 225, 230), "inspect": (255, 193, 69),
               "dock": (179, 136, 255), "sample": (128, 237, 153)}

_FONT_CACHE = {}
_FAMILIES = ["jetbrainsmononerdfontpropo", "jetbrainsmononerdfont", "dejavusans",
             "notosans", "freesans"]


def font(size: int, bold: bool = False) -> pygame.font.Font:
    key = (size, bold)
    if key not in _FONT_CACHE:
        f = None
        for fam in _FAMILIES:
            path = pygame.font.match_font(fam, bold=bold)
            if path:
                f = pygame.font.Font(path, size)
                break
        if f is None:
            f = pygame.font.Font(None, int(size * 1.3))
            f.set_bold(bold)
        _FONT_CACHE[key] = f
    return _FONT_CACHE[key]


def lerp(a, b, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(len(a)))
