"""Procedural ocean rendering, sprites and particle effects (visual only).

All randomness here uses a private random.Random so visuals can never perturb the
simulation's exogenous random streams."""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import List, Tuple

import numpy as np
import pygame
from scipy import ndimage

from . import theme as T

VRNG = random.Random(12345)
_GLOW = {}


def glow(color, radius: int, strength: float = 1.0) -> pygame.Surface:
    """Radial-gradient sprite for additive blending."""
    radius = max(2, int(radius))
    key = (tuple(color), radius, round(strength, 2))
    if key not in _GLOW:
        d = radius * 2
        yy, xx = np.mgrid[0:d, 0:d]
        r = np.hypot(xx - radius + 0.5, yy - radius + 0.5) / radius
        a = np.clip(1 - r, 0, 1) ** 2 * strength
        surf = pygame.Surface((d, d))
        arr = np.zeros((d, d, 3))
        for c in range(3):
            arr[..., c] = color[c] * a
        pygame.surfarray.blit_array(surf, np.clip(arr, 0, 255).astype(np.uint8).transpose(1, 0, 2))
        _GLOW[key] = surf
    return _GLOW[key]


def blit_glow(dst, color, pos, radius, strength=1.0):
    g = glow(color, radius, strength)
    dst.blit(g, (pos[0] - g.get_width() // 2, pos[1] - g.get_height() // 2),
             special_flags=pygame.BLEND_ADD)


def caustics_texture(size=256, seed=3, intensity=1.0) -> pygame.Surface:
    """Tileable Voronoi-edge caustic net (bright filaments where light focuses)."""
    rng = np.random.default_rng(seed)
    pts = rng.uniform(0, size, (34, 2))
    yy, xx = np.mgrid[0:size, 0:size].astype(float)
    d1 = np.full((size, size), 1e9); d2 = np.full((size, size), 1e9)
    for px, py in pts:
        for ox in (-size, 0, size):
            for oy in (-size, 0, size):
                d = np.hypot(xx - px - ox, yy - py - oy)
                closer = d < d1
                d2 = np.where(closer, d1, np.minimum(d2, d))
                d1 = np.where(closer, d, d1)
    edge = np.clip(1 - (d2 - d1) / 7.0, 0, 1) ** 2.2
    edge = ndimage.gaussian_filter(edge, 0.8, mode="wrap")
    edge = edge / edge.max() * intensity
    arr = np.zeros((size, size, 3))
    arr[..., 0] = 26 * edge; arr[..., 1] = 60 * edge; arr[..., 2] = 66 * edge
    surf = pygame.Surface((size, size))
    pygame.surfarray.blit_array(surf, arr.astype(np.uint8).transpose(1, 0, 2))
    return surf


def water_mask(world, scale) -> pygame.Surface:
    """White on open water, fading to black over land/shallows (for masking shimmer)."""
    clr = np.flipud(np.clip((world.clearance - 0.5) / 3.0, 0, 1))
    arr = np.repeat((clr * 255).astype(np.uint8)[..., None], 3, axis=2)
    small = pygame.Surface((clr.shape[1], clr.shape[0]))
    pygame.surfarray.blit_array(small, arr.transpose(1, 0, 2))
    return pygame.transform.smoothscale(small, (int(world.width * scale), int(world.height * scale)))


def land_texture(size=(512, 512), seed=5) -> pygame.Surface:
    rng = np.random.default_rng(seed)
    n = ndimage.gaussian_filter(rng.standard_normal((size[1] // 4, size[0] // 4)), 3, mode="wrap")
    n = (n - n.min()) / (n.max() - n.min() + 1e-9)
    arr = np.zeros((*n.shape, 3))
    for c, (a, b) in enumerate(zip((30, 52, 38), (52, 86, 56))):
        arr[..., c] = a + (b - a) * n
    small = pygame.Surface((n.shape[1], n.shape[0]))
    pygame.surfarray.blit_array(small, arr.astype(np.uint8).transpose(1, 0, 2))
    return pygame.transform.smoothscale(small, size)


def _offset_poly(poly: np.ndarray, d: float) -> np.ndarray:
    """Approximate polygon offset by radial scaling around the centroid."""
    c = poly.mean(0)
    v = poly - c
    r = np.linalg.norm(v, axis=1, keepdims=True) + 1e-9
    return c + v * np.maximum(r + d, 0.2) / r


def render_static(world, scale: float, tasks=()) -> pygame.Surface:
    """Bake water depth shading, shoreline foam, islands, rocks, piers at `scale` px/m."""
    W, H = world.width, world.height
    pw, ph = int(W * scale), int(H * scale)
    # --- water colour from clearance (shallow near land) + low-frequency noise --------
    clr = world.clearance
    ny, nx = clr.shape
    rng = np.random.default_rng(world.seed + 99)
    noise = ndimage.gaussian_filter(rng.standard_normal((ny, nx)), 6)
    noise = noise / (np.abs(noise).max() + 1e-9)
    depth = np.clip(clr / 14.0, 0, 1) ** 0.7
    depth = np.clip(depth + 0.08 * noise, 0, 1)
    cols = np.zeros((ny, nx, 3))
    for c in range(3):
        shallow, mid, deep = T.SHALLOW[c], T.MID[c], T.DEEP[c]
        cols[..., c] = np.where(depth < 0.35, shallow + (mid - shallow) * depth / 0.35,
                                mid + (deep - mid) * (depth - 0.35) / 0.65)
    cols = np.flipud(cols)                              # world y up -> screen y down
    small = pygame.Surface((nx, ny))
    pygame.surfarray.blit_array(small, np.clip(cols, 0, 255).astype(np.uint8).transpose(1, 0, 2))
    surf = pygame.transform.smoothscale(small, (pw, ph))

    def P(poly):
        return [(float(x * scale), float((H - y) * scale)) for x, y in poly]

    # shoreline foam + beach + vegetation
    foam = pygame.Surface((pw, ph), pygame.SRCALPHA)
    for isl in world.islands:
        for d, a in ((2.2, 30), (1.4, 55), (0.8, 90)):
            pygame.draw.polygon(foam, (*T.FOAM, a), P(_offset_poly(isl, d)))
    for rk in world.rocks:
        pygame.draw.polygon(foam, (*T.FOAM, 45), P(_offset_poly(rk, 1.0)))
    surf.blit(foam, (0, 0))
    for isl in world.islands:
        pygame.draw.polygon(surf, T.SAND_DARK, P(_offset_poly(isl, 0.4)))
        pygame.draw.polygon(surf, T.SAND, P(isl))
        inner = _offset_poly(isl, -1.6)
        pygame.draw.polygon(surf, T.GRASS_DARK, P(inner))
        pygame.draw.polygon(surf, T.GRASS, P(_offset_poly(inner, -0.6)))
        # trees: deterministic visual scatter
        c = isl.mean(0)
        r = np.linalg.norm(isl - c, axis=1).min()
        vr = random.Random(int(c[0] * 7 + c[1] * 13))
        for _ in range(int(r * 1.2)):
            a = vr.uniform(0, 2 * math.pi); rr = vr.uniform(0, max(0.5, r - 2.5))
            tx, ty = c[0] + rr * math.cos(a), c[1] + rr * math.sin(a)
            tr = vr.uniform(0.7, 1.4) * scale
            sx, sy = tx * scale, (H - ty) * scale
            pygame.draw.circle(surf, (25, 60, 40), (sx + tr * 0.35, sy + tr * 0.35), tr)
            pygame.draw.circle(surf, (52, 112, 66), (sx, sy), tr)
            pygame.draw.circle(surf, (84, 150, 88), (sx - tr * 0.3, sy - tr * 0.3), tr * 0.45)
    for rk in world.rocks:
        pygame.draw.polygon(surf, (60, 56, 54), P(_offset_poly(rk, 0.3)))
        pygame.draw.polygon(surf, T.ROCK, P(rk))
        hl = rk + np.array([-0.3, 0.3])
        pygame.draw.polygon(surf, T.ROCK_LIGHT, P(_offset_poly(hl, -1.0)))
    for pr in world.piers:
        pygame.draw.polygon(surf, T.WOOD_DARK, P(_offset_poly(pr, 0.2)))
        pygame.draw.polygon(surf, T.WOOD, P(pr))
        # planks
        a, b, c, d = pr
        for f in np.linspace(0.1, 0.9, 6):
            p1 = a + (b - a) * f; p2 = d + (c - d) * f
            pygame.draw.line(surf, T.WOOD_DARK, P([p1])[0], P([p2])[0], 1)
    # launch zone marking
    lx, ly = world.launch
    rect = pygame.Rect(0, 0, 14 * scale, 34 * scale)
    rect.center = (lx * scale, (H - ly) * scale)
    zone = pygame.Surface(rect.size, pygame.SRCALPHA)
    zone.fill((92, 225, 230, 18))
    pygame.draw.rect(zone, (92, 225, 230, 90), zone.get_rect(), 2, border_radius=6)
    surf.blit(zone, rect.topleft)
    # arena border
    pygame.draw.rect(surf, (20, 40, 55), surf.get_rect(), max(2, int(scale)))
    return surf


# ---------------------------------------------------------------------------------
# Boat sprite: twin-hull autonomous catamaran
# ---------------------------------------------------------------------------------
_BOAT = {}


def boat_sprite(color, length_px: int) -> pygame.Surface:
    """Top-down catamaran pointing +x. Drawn at 4x then smooth-scaled for AA."""
    length_px = max(14, int(length_px))
    key = (tuple(color), length_px)
    if key in _BOAT:
        return _BOAT[key]
    S = 4
    L = length_px * S
    Wd = int(L * 0.62)
    surf = pygame.Surface((L, Wd), pygame.SRCALPHA)
    hull_w = Wd * 0.26
    for yc in (hull_w * 0.62, Wd - hull_w * 0.62):
        pts = [(L * 0.02, yc - hull_w / 2), (L * 0.72, yc - hull_w / 2), (L * 0.98, yc),
               (L * 0.72, yc + hull_w / 2), (L * 0.02, yc + hull_w / 2)]
        pygame.draw.polygon(surf, (24, 30, 38), [(x + S, y + S) for x, y in pts])   # shadow
        pygame.draw.polygon(surf, (232, 238, 244), pts)
        pygame.draw.polygon(surf, color, [(L * 0.08, yc - hull_w * 0.18), (L * 0.66, yc - hull_w * 0.18),
                                          (L * 0.80, yc), (L * 0.66, yc + hull_w * 0.18),
                                          (L * 0.08, yc + hull_w * 0.18)])
        # thruster pods
        pygame.draw.rect(surf, (40, 44, 52), (0, yc - hull_w * 0.22, L * 0.06, hull_w * 0.44))
    # deck
    deck = pygame.Rect(L * 0.18, hull_w * 0.55, L * 0.50, Wd - hull_w * 1.1)
    pygame.draw.rect(surf, (44, 56, 70), deck, border_radius=int(S * 2))
    pygame.draw.rect(surf, color, deck, max(1, S), border_radius=int(S * 2))
    # solar panel + lidar dome + antenna
    sp = pygame.Rect(L * 0.22, deck.top + deck.height * 0.18, L * 0.24, deck.height * 0.64)
    pygame.draw.rect(surf, (30, 60, 110), sp, border_radius=S)
    for k in range(1, 4):
        x = sp.left + sp.width * k / 4
        pygame.draw.line(surf, (70, 110, 170), (x, sp.top), (x, sp.bottom), max(1, S // 2))
    pygame.draw.circle(surf, (20, 22, 26), (L * 0.58, Wd / 2), deck.height * 0.24)
    pygame.draw.circle(surf, (120, 220, 255), (L * 0.58, Wd / 2), deck.height * 0.14)
    pygame.draw.circle(surf, (255, 255, 255), (L * 0.565, Wd / 2 - deck.height * 0.05), deck.height * 0.05)
    out = pygame.transform.smoothscale(surf, (length_px, max(6, int(length_px * 0.62))))
    _BOAT[key] = out
    return out


def draw_boat(dst, pos, psi, color, length_px):
    spr = boat_sprite(color, length_px)
    rot = pygame.transform.rotozoom(spr, math.degrees(psi), 1.0)
    dst.blit(rot, (pos[0] - rot.get_width() / 2, pos[1] - rot.get_height() / 2))


# ---------------------------------------------------------------------------------
# Particles
# ---------------------------------------------------------------------------------
@dataclass
class Particle:
    x: float           # world coords
    y: float
    vx: float
    vy: float
    life: float
    max_life: float
    color: tuple
    size: float
    kind: str = "spark"      # spark | wake | ring | text | confetti | smoke
    text: str = ""
    grow: float = 0.0
    spin: float = 0.0
    ang: float = 0.0


class Particles:
    def __init__(self):
        self.items: List[Particle] = []

    def update(self, dt):
        keep = []
        for p in self.items:
            p.life -= dt
            if p.life <= 0:
                continue
            p.x += p.vx * dt; p.y += p.vy * dt
            if p.kind in ("spark", "confetti"):
                p.vx *= (1 - 1.8 * dt); p.vy *= (1 - 1.8 * dt)
            if p.kind == "text":
                p.vy *= (1 - 1.2 * dt)
            p.size += p.grow * dt
            p.ang += p.spin * dt
            keep.append(p)
        self.items = keep

    # --- emitters ---------------------------------------------------------------
    def burst(self, x, y, color, n=60, speed=9.0):
        for _ in range(n):
            a = VRNG.uniform(0, 2 * math.pi); s = VRNG.uniform(0.3, 1.0) * speed
            life = VRNG.uniform(0.6, 1.4)
            c = color if VRNG.random() < 0.6 else (255, 255, 230)
            self.items.append(Particle(x, y, s * math.cos(a), s * math.sin(a), life, life, c,
                                       VRNG.uniform(0.25, 0.6), "spark"))
        for _ in range(n // 2):
            a = VRNG.uniform(0, 2 * math.pi); s = VRNG.uniform(0.2, 1.0) * speed * 0.6
            life = VRNG.uniform(1.0, 2.0)
            self.items.append(Particle(x, y, s * math.cos(a), s * math.sin(a), life, life,
                                       VRNG.choice(T.BOAT_COLORS), VRNG.uniform(0.35, 0.7), "confetti",
                                       spin=VRNG.uniform(-8, 8), ang=VRNG.uniform(0, 6)))
        self.items.append(Particle(x, y, 0, 0, 1.1, 1.1, color, 1.0, "ring", grow=22.0))
        self.items.append(Particle(x, y, 0, 0, 0.7, 0.7, (255, 255, 255), 0.5, "ring", grow=34.0))
        self.items.append(Particle(x, y, 0, 0, 1.6, 1.6, color, 1.0, "ring", grow=10.0))
        self.items.append(Particle(x, y, 0, 0, 1.4, 1.4, color, 6.0, "flash"))
        self.items.append(Particle(x, y, 0, 0, 1.2, 1.2, color, 1.0, "pillar"))
        # rising embers
        for _ in range(26):
            life = VRNG.uniform(1.0, 2.2)
            self.items.append(Particle(x + VRNG.uniform(-2, 2), y + VRNG.uniform(-2, 2), VRNG.uniform(-0.6, 0.6),
                                       VRNG.uniform(3, 8), life, life, (255, 230, 150), VRNG.uniform(0.15, 0.3), "spark"))

    def text(self, x, y, s, color, life=1.8, size=1.0):
        self.items.append(Particle(x, y + 2, 0, 5.0, life, life, color, size, "text", text=s))

    def sparks(self, x, y, color=(255, 160, 60), n=24):
        for _ in range(n):
            a = VRNG.uniform(0, 2 * math.pi); s = VRNG.uniform(2, 8)
            life = VRNG.uniform(0.3, 0.8)
            self.items.append(Particle(x, y, s * math.cos(a), s * math.sin(a), life, life, color,
                                       VRNG.uniform(0.2, 0.4), "spark"))

    def smoke(self, x, y, color=(150, 150, 160), n=10):
        for _ in range(n):
            a = VRNG.uniform(0, 2 * math.pi); s = VRNG.uniform(0.3, 1.5)
            life = VRNG.uniform(1.0, 1.8)
            self.items.append(Particle(x, y, s * math.cos(a), s * math.sin(a), life, life, color,
                                       VRNG.uniform(0.6, 1.0), "smoke", grow=1.2))

    def wake(self, x, y, psi, speed, color=(230, 245, 250)):
        if speed < 0.15:
            return
        # two diverging arms of a Kelvin-like V
        for side in (-1, 1):
            a = psi + math.pi + side * 0.42
            s = 0.45 + 0.3 * speed
            life = 2.6 + 0.6 * speed
            self.items.append(Particle(x + VRNG.uniform(-0.1, 0.1), y + VRNG.uniform(-0.1, 0.1),
                                       s * math.cos(a), s * math.sin(a), life, life, color,
                                       0.12, "wake", grow=0.16))

    def prop(self, x, y, psi, thrust):
        if thrust < 0.05:
            return
        a = psi + math.pi + VRNG.uniform(-0.25, 0.25)
        s = 1.2 + 2.5 * thrust
        life = 0.45
        self.items.append(Particle(x, y, s * math.cos(a), s * math.sin(a), life, life,
                                   (215, 245, 255), 0.08 + 0.06 * thrust, "wake", grow=0.35))


def draw_particles(dst, parts: Particles, cam, layer="all", font_cache={}):
    s = cam.scale
    add = []
    for p in parts.items:
        f = p.life / p.max_life
        if layer == "wake" and p.kind != "wake":
            continue
        if layer == "fx" and p.kind == "wake":
            continue
        X, Y = cam.to_screen(p.x, p.y)
        if not (-50 < X < cam.vw + cam.vx + 50 and -50 < Y < cam.vh + cam.vy + 50):
            continue
        if p.kind == "wake":
            r = max(1, int(p.size * s * cam.boat_exag ** 0.5))
            a = int(95 * f * f)
            pygame.draw.circle(dst, (*p.color, a), (X, Y), r, 1)
        elif p.kind == "spark":
            add.append((p.color, (X, Y), max(2, int(p.size * s * 2.2 * f + 2)), f))
        elif p.kind == "confetti":
            w = max(2, int(p.size * s * 0.9)); h = max(1, int(w * 0.5 * abs(math.cos(p.ang))))
            r = pygame.Rect(0, 0, w, max(1, h)); r.center = (X, Y)
            pygame.draw.rect(dst, (*p.color, int(255 * min(1, f * 1.5))), r)
        elif p.kind == "ring":
            r = max(1, int(p.size * s))
            pygame.draw.circle(dst, (*p.color, int(200 * f)), (X, Y), r, max(1, int(3 * f + 1)))
        elif p.kind == "flash":
            add.append((p.color, (X, Y), max(4, int(p.size * s * f)), f))
        elif p.kind == "pillar":
            h = int(min(220, 30 * s) * (0.6 + 0.4 * f))
            w = max(3, int(2.2 * s * f))
            col = p.color
            for k in range(6):
                a = int(150 * f * (1 - k / 6))
                pygame.draw.line(dst, (*col, a), (X, Y - h * k / 6), (X, Y - h * (k + 1) / 6), w)
            pygame.draw.line(dst, (255, 255, 255, int(220 * f)), (X, Y), (X, Y - h * 0.7), max(1, w // 3))
        elif p.kind == "smoke":
            r = max(1, int(p.size * s))
            pygame.draw.circle(dst, (*p.color, int(70 * f)), (X, Y), r)
        elif p.kind == "text":
            key = (int(18 * p.size), True)
            fnt = T.font(*key)
            img = fnt.render(p.text, True, p.color)
            img.set_alpha(int(255 * min(1, f * 2)))
            sh = fnt.render(p.text, True, (0, 0, 0)); sh.set_alpha(int(200 * min(1, f * 2)))
            for ox, oy in ((-2, 0), (2, 0), (0, -2), (0, 2), (2, 2)):
                dst.blit(sh, (X - img.get_width() / 2 + ox, Y - img.get_height() / 2 + oy))
            dst.blit(img, (X - img.get_width() / 2, Y - img.get_height() / 2))
    return add


class FlowField:
    """Tracer particles advected by the TRUE current (what you would see on the water)."""

    def __init__(self, world, n=900, seed=7):
        self.world = world
        self.rng = np.random.default_rng(seed)
        self.n = n
        self.x = self.rng.uniform(0, world.width, n)
        self.y = self.rng.uniform(0, world.height, n)
        self.age = self.rng.uniform(0, 6, n)
        self.life = self.rng.uniform(4, 8, n)
        self.px, self.py = self.x.copy(), self.y.copy()

    def update(self, t, dt, speedup=6.0):
        u, v = self.world.current.total(self.x, self.y, t)
        self.px, self.py = self.x.copy(), self.y.copy()
        self.x += u * dt * speedup
        self.y += v * dt * speedup
        self.age += dt
        W = self.world
        ii = np.clip((self.y / W.res).astype(int), 0, W.shape[0] - 1)
        jj = np.clip((self.x / W.res).astype(int), 0, W.shape[1] - 1)
        dead = (self.age > self.life) | W.blocked[ii, jj] | (self.x < 0) | (self.x > W.width) \
            | (self.y < 0) | (self.y > W.height)
        k = int(dead.sum())
        if k:
            self.x[dead] = self.rng.uniform(0, W.width, k)
            self.y[dead] = self.rng.uniform(0, W.height, k)
            self.px[dead], self.py[dead] = self.x[dead], self.y[dead]
            self.age[dead] = 0
            self.life[dead] = self.rng.uniform(4, 8, k)
        self.speed = np.hypot(u, v)

    def draw(self, dst, cam):
        f = np.clip(np.minimum(self.age, self.life - self.age) / 1.2, 0, 1)
        for i in range(self.n):
            if f[i] <= 0.05:
                continue
            a = cam.to_screen(self.px[i], self.py[i])
            b = cam.to_screen(self.x[i], self.y[i])
            sp = min(1.0, self.speed[i] / 0.5)
            c = (int(150 + 100 * sp), int(215 + 40 * sp), 255, int(230 * f[i] * (0.35 + 0.65 * sp)))
            pygame.draw.line(dst, c, a, b, 2 if sp > 0.6 else 1)
